library(dplyr)

# ultimate list
ulist.path <-
  "S:\\DataAnalysis\\01_CombinedClinicalGeneticModel\\C_01_OneGeneSelectedCD\\01_Data\\ModelUniref100_01\\50_ProcessedData\\"
ulist <- 
  read.csv(paste(ulist.path,"Reduced_ANOVA_OneGeneSelectedCD.csv",sep=""))
ulist <- filter(ulist,Include == 1)

# Scoary Input file at least containing these data:
Scoary.Input.path <- 
  "S:\\DataAnalysis\\01_CombinedClinicalGeneticModel\\K_01_Scoary\\01_Data\\A_ScoaryResults\\UniRef100\\01\\"
Scoary.Input <- 
  read.csv(paste(Scoary.Input.path,"genes_Training_BP02_C_AfterPropTestSieving.csv",sep = "")) 

head(Scoary.Input)
Scoary.Output <- Scoary.Input[which(Scoary.Input$GEN %in% ulist$Gene),]
dim(Scoary.Output)
Scoary.Output.path <- 
  "S:\\DataAnalysis\\01_CombinedClinicalGeneticModel\\K_01_Scoary\\01_Data\\A_ScoaryResults\\UniRef100\\03\\"
write.csv(Scoary.Output,
      paste(Scoary.Output.path,"genes_Training_BP02_ultimate.csv",sep = ""), quote = FALSE, row.names = FALSE)
