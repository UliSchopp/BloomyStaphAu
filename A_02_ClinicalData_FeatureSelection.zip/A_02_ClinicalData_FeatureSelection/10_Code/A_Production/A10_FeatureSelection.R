#####################################################################
#   A10_FeatureSelection:                                           #
#                                                                   #
#   This code implements:                                           #
#   1. feature selection process for clinical data                  #
#   2. some analysis                                                #
#   3. ROC plots                                                    #
#                                                                   #
#   ATTENTION: Reading the data is controlled by one central        #
#              file!                                                #
#####################################################################

library(car)
library(dplyr)
library(writexl)

#=======================#
#   1. Fix file paths   #
#=======================#

source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_02_ClinicalData_FeatureSelection/01_Data/10_ControlFiles/ControlFile.R")

#=======================================================#
#   2. Prepare the file for the in-line-analysis        #
#=======================================================#

ILA_file <- paste(in_line_analysis_folder,"ILA_ClinicalDataFeatureSelection.txt",sep = "")
if(file.exists(ILA_file)){
  file.remove(ILA_file)  
}else{
  file.create(ILA_file)
}

#========================#
#   3. Read data         #
#========================#

StaphDaten <- 
  read.csv(
    paste(path_I,
          "SA_Data_Step06.csv", 
          sep = ""))

StaphDaten <- data.frame(StaphDaten)

ValDaten   <- filter(StaphDaten, TrainingData == 0)
TraDaten   <- filter(StaphDaten, TrainingData == 1)

#======================================================#
#   4. Which are the features we have in mind?         #
#======================================================#

Features <- c("age_aufstat",
              "appropriatenessByInspection",
              "BMI",
              "CCI",
              "entl_ort_ent",
              "focus_harmonized",
              "sex_mb",
              "pbs_t0")

# Trainingsdaten
selTraDaten <-TraDaten[,Features]
# Validierungsdaten
selValDaten <-ValDaten[,Features]

#======================================================#
#   5. Delete Incomplete Data Sets                     #
#======================================================#

# ... training data
for(i in 1:dim(selTraDaten)[2]){
  tmp <- which(is.na(selTraDaten[,i]))
  if(length(tmp) > 0){
    selTraDaten <- selTraDaten[-tmp,]
  }
}
selTraDaten$entl_ort_ent <- factor(ifelse(selTraDaten$entl_ort_ent == "Im Krankenhaus verstorben",1,0))

# ... validation data
for(i in 1:dim(selValDaten)[2]){
  tmp <- which(is.na(selValDaten[,i]))
  if(length(tmp) > 0){
    selValDaten <- selValDaten[-tmp,]
  }
}
selValDaten$entl_ort_ent <- factor(ifelse(selValDaten$entl_ort_ent == "Im Krankenhaus verstorben",1,0))

#======================================================#
#   6. Feature selection by ANOVA                      #
#======================================================#

# Initialisation
glm_res <- glm(entl_ort_ent ~ ., data = selTraDaten, family = "binomial")
anres <- Anova(glm_res)

write.table(anres,paste(in_line_analysis_folder,"ANOVA_beforeSelection.txt",sep = ""),quote = FALSE)

write.table("ANOVA before selection:",ILA_file,
            quote = FALSE, append = TRUE,
            row.names = FALSE, col.names = FALSE)
write.table(anres,ILA_file,quote = FALSE, append = TRUE)

odf <- data.frame("Clinical Parameters" = rownames(anres),
           "Pr(>Chisq)" = round(anres[,3],4),
           check.names = FALSE)
write_xlsx(odf,paste(report_and_analysis_folder,"ANOVA_beforeSelection.xlsx",sep = ""))

# Stepping
mr <- max(anres$`Pr(>Chisq)`)

while (mr > mr.threshold & dim(anres)[1] > dim.threshold){
  (tmp <- which(anres$`Pr(>Chisq)` == mr)[1])
  row.names(anres)[tmp]
  tmp <- which(colnames(selTraDaten) == row.names(anres)[tmp])
  selTraDaten <- selTraDaten[,-tmp]
  glm_res <- glm(entl_ort_ent ~ ., data = selTraDaten, family = "binomial")
  (anres <- Anova(glm_res))
  (mr <- max(anres$`Pr(>Chisq)`))
}

write.table(anres,paste(in_line_analysis_folder,"ANOVA_afterSelection.txt",sep = ""),quote = FALSE)
write.table("\nANOVA after selection:",ILA_file,quote = FALSE, append = TRUE,
            row.name = FALSE, col.names = FALSE)
write.table(anres,ILA_file,quote = FALSE, append = TRUE)

odf <- data.frame("Clinical Parameters" = rownames(anres),
                  "Pr(>Chisq)" = round(anres[,3],4),
                  check.names = FALSE)
write_xlsx(odf,paste(report_and_analysis_folder,"ANOVA_afterSelection.xlsx",sep = ""))

featInModel <- rownames(anres)

write(rownames(anres),
      paste(out_data_folder ,
            "Preliminary_ClinicalFeatureSet.csv", 
            sep = ""))

#======================================================#
#   7. Analysis of Residual Deviance                   #
#======================================================#
# Bilder, Loughin, p. 82

##residualDeviance -> Excel
residualDeviance <- 
  data.frame(
    name = rep(NA, length(featInModel)),
    `H0 deviance` = rep(NA, length(featInModel)), 
    `HA deviance` = rep(NA, length(featInModel)),
    df = rep(NA, length(featInModel)),
    `statistic's value` = rep(NA, length(featInModel)),
    `p value`   = rep(NA, length(featInModel)),
    check.names=FALSE
  )


for(i in 1:length(featInModel)){
  H0FeatIndex <- 
    which(colnames(selTraDaten) == featInModel[i])
  glm_res_H0 <- 
    glm(entl_ort_ent ~ ., data = selTraDaten[,-H0FeatIndex], family = "binomial")
  df <- 
    glm_res_H0$df.residual - glm_res$df.residual 
  stat <-
    glm_res_H0$deviance - glm_res$deviance
  pval <- 
    1 - pchisq(q = stat, df = df)
  residualDeviance[i,1] <- featInModel[i]
  residualDeviance[i,2] <- glm_res_H0$deviance 
  residualDeviance[i,3] <- glm_res$deviance
  residualDeviance[i,4] <- df
  residualDeviance[i,5] <- stat
  residualDeviance[i,6] <- format(round(pval, 5), nsmall = 5, format = "f", scientific=F)
}
residualDeviance

write.table(residualDeviance,paste(in_line_analysis_folder,"ResidualDeviance.txt",sep = ""),quote = FALSE)
write.table("\nResidual Deviance:",ILA_file,quote = FALSE, append = TRUE,
            row.names = FALSE, col.names = FALSE)
write.table(residualDeviance,ILA_file,quote = FALSE, append = TRUE, row.names = FALSE)

write_xlsx(residualDeviance,paste(report_and_analysis_folder,"ResidualDeviance.xlsx",sep = ""))

#======================================================#
#   8. Confidence Intervals                            #
#======================================================#
odf <- confint(glm_res, level = confidence.level)
odf <- data.frame(odf, check.names = FALSE)

write.table(odf,paste(in_line_analysis_folder,"ConfidenceIntervals.txt",sep = ""),quote = FALSE)
write.table("\n Confidence Intervals:",ILA_file,quote = FALSE, append = TRUE,
            row.names = FALSE, col.names = FALSE)
write.table(odf,ILA_file,quote = FALSE, append = TRUE, row.names = FALSE)

write_xlsx(residualDeviance,paste(report_and_analysis_folder,"ConfidenceIntervals.xlsx",sep = ""))

#======================================================#
#   9. Hosmer Lemshow Test                             #
#======================================================#

####  Hosmer Lemshow Test: from the Help File:
#  The Hosmer-Lemeshow tests The Hosmer-Lemeshow tests are goodness of fit 
#tests for binary, multinomial and ordinal logistic regression models. 
#logitgof is capable of performing all three. 
#Essentially, they compare observed with expected frequencies of 
#the outcome and compute a test statistic which is distributed according 
#to the chi-squared distribution. The degrees of freedom depend upon 
#the number of quantiles used and the number of outcome categories. 
#A non-significant p value indicates that there is no evidence that 
#the observed and expected frequencies differ (i.e., evidence of good fit). 

library(generalhoslem)

write.table("\nHosmer Lemshow Test:",ILA_file,quote = FALSE, append = TRUE, col.names = FALSE, row.names = FALSE)
odf <- 
  logitgof(selTraDaten$entl_ort_ent, fitted(glm_res))
write.table(round(odf$p.value,4),ILA_file,quote = FALSE, append = TRUE, row.names = FALSE, col.names = FALSE)


#======================================================#
#   10. ROC Curves                                     #
#======================================================#

glm_predicts <- 
  predict(glm_res, type = "response")
## Vorhersage für Trainingsdaten 
df_TraPredictions  <-  data.frame(outcome = as.numeric(selTraDaten$entl_ort_ent)-1, 
                                  pred = fitted(glm_res))

## Vorhersage für Validierungsdaten 
glm_ValPredictions  <-  
  predict(glm_res, 
          type = "response", 
          newdata = selValDaten[,featInModel])
df_ValPredictions  <-  data.frame(outcome = as.numeric(as.vector(selValDaten$entl_ort_ent)), 
                                  pred = glm_ValPredictions)

library(plotROC)
library(PRROC)
library(OptimalCutpoints)

# Beste Parameter für Training
optimal.cutpoint.Youden.Tra <- 
  optimal.cutpoints(X = "pred", 
                    status = "outcome", 
                    tag.healthy = 0,
                    methods = "Youden", 
                    data = df_TraPredictions, 
                    pop.prev = NULL, 
                    control = control.cutpoints(), 
                    ci.fit = TRUE, conf.level = conf.level.ROC, trace = FALSE)

optimal.cutpoint.Youden.Tra$Youden$Global$measures.acc$AUC

write.table("\nArea under the ROC curve for taining data:",
            ILA_file,quote = FALSE, append = TRUE, row.names = FALSE, col.names = FALSE)
write.table(round(optimal.cutpoint.Youden.Tra$Youden$Global$measures.acc$AUC,3),
            ILA_file,quote = FALSE, append = TRUE, row.names = FALSE)


out.Tra <- optimal.cutpoint.Youden.Tra$Youden$Global$measures.acc$AUC

df_TraPredictions$outcome <- as.numeric(df_TraPredictions$outcome)

# Beste Parameter für Validierung
optimal.cutpoint.Youden.Val <- 
  optimal.cutpoints(X = "pred", 
                    status = "outcome", 
                    tag.healthy = 0,
                    methods = "Youden", 
                    data = df_ValPredictions, 
                    pop.prev = NULL, 
                    control = control.cutpoints(), 
                    ci.fit = TRUE, conf.level = conf.level.ROC, trace = FALSE)
optimal.cutpoint.Youden.Val
write.table("\nArea under the ROC curve for validatoin data:",
            ILA_file,quote = FALSE, append = TRUE, row.names = FALSE, col.names = FALSE)
write.table(round(optimal.cutpoint.Youden.Val$Youden$Global$measures.acc$AUC,3),
            ILA_file,quote = FALSE, append = TRUE, row.names = FALSE)

out.Val <- optimal.cutpoint.Youden.Val$Youden$Global$measures.acc$AUC


df_predictions_training    <-  df_TraPredictions
df_predictions_validation  <-  df_ValPredictions

df_predictions_training$Type   <- "Training"
df_predictions_validation$Type <- "Validation"
df_predictions <- rbind(df_predictions_training,
                        df_predictions_validation)
df_predictions <- data.frame(df_predictions)
#head(df_predictions)


ggplot(df_predictions, 
       aes(d = outcome, m = pred, color = Type)) + 
  geom_roc(n.cut = 0) +
  style_roc() + 
  geom_abline(slope = 1,
              intercept = 0, 
              color = "grey50") +
  ggtitle(paste("ROC Curves for", paste0(featInModel, collapse = ", ")))
ggsave(paste(report_and_analysis_folder,"ROC_OnlyClinicalParameter.pdf",sep = ""))

