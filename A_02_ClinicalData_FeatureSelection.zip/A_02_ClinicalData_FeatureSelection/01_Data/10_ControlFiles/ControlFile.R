#######################################################################
#   This code serves as the central control file                      #
#   comprising the model's name and paths to all in- and output files #
#   concerned with "only gene steps".                                 #
#######################################################################

path_I <- 
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_01_PreparationOfClinicalData/01_Data/50_ProcessedData/"

path_II <-
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_02_ClinicalData_FeatureSelection/01_Data/"
out_data_folder <- 
  paste(path_II,"50_ProcessedData/",sep="")
in_line_analysis_folder <- 
  paste(path_II,"20_InLineAnalysis/",sep="")
report_and_analysis_folder <- 
  paste(path_II,"70_AnalysisAndOverview/",sep="")

# Parameter for ANOVA Feature Selection
mr.threshold <- 0.05
dim.threshold <- 3

# Parameter for confidence level calculation in ANOVA
confidence.level <- 0.95

# Parameter for confidence level calculation in ROC Curve analysis
conf.level.ROC <- 0.95