library(readxl)
library(writexl)
library(Hmisc)
library(dplyr)

# Former Name: DEV_010_BloomyPredict.R
# Current Name: AP01

#==============================#
#    1. Reading the Data       #
#==============================#

source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_01_PreparationOfClinicalData/01_Data/10_ControlFiles/ControlFile.R")

# only in the first code of a sequence!
file.remove(paste(output_data_folder,list.files(output_data_folder, recursive = TRUE),sep = ""))
file.remove(paste(output_data_folder,list.files(output_inline_analysis, recursive = TRUE),sep = ""))


# Data from BLOOMY and PREDICT studies are hosted in two different Excel workbooks.
# The data model of these studies are different. 
# This makes data processing awkward.

bloomy <- 
   read_excel(paste(initial_data_folder, "bloomydata_20200130_asofdec2023_v3.xlsx", sep = ""))

predict <- 
  read_excel(paste(initial_data_folder,"predictdata_20210511_asofdec2023_v1.xlsx", sep =""))

#==========================================#
#    2. Selection of relevant fields       #
#==========================================#

# The data models of both studies is quite large. Many information is irrelvant
# in the further analysis. So we create extracts.
# Unfortunately due to different models the data field names differ. 
# Additionally sometimes data fields that are present in one model are lacking
# in the other. 
# To deal with that and to be flexible we control the extract by using a
# specific file containing the names of relevant data fields to be used 
# from both studies.

relevantFields <- 
  read_xlsx(paste(field_list_folder,"FeldListeBLOOMY_Version_03.xlsx",sep =""),
                            col_names = TRUE)
head(relevantFields)


BLOOMY_FIELDS <- filter(relevantFields,MML_BLOOMY %nin% c("NA","berechnet"))$Variable_BLOOMY
if(length(is.na(BLOOMY_FIELDS)) > 0){
  BLOOMY_FIELDS <- BLOOMY_FIELDS[-which(is.na(BLOOMY_FIELDS))]
}

PREDICT_FIELDS <- filter(relevantFields,MML_BLOOMY %nin% c("NA","berechnet"))$Variable_PREDICT
if(length(is.na(PREDICT_FIELDS)) > 0){
  PREDICT_FIELDS <- PREDICT_FIELDS[-which(is.na(PREDICT_FIELDS))]
}

tmp_bloomy  <- which(colnames(bloomy) %in% BLOOMY_FIELDS)
tmp_predict <- which(colnames(predict) %in% PREDICT_FIELDS)

# Just a check!

BLOOMY_FIELDS[which(BLOOMY_FIELDS %nin% colnames(bloomy))]
PREDICT_FIELDS[which(PREDICT_FIELDS %nin% colnames(predict))]

#==========================================#
#    3. Harmonize the fields               #
#==========================================#

# As mentioned the data models of the two studies differ. 
# We try to harmonize the models. 

bloomyDataExtrakt <- bloomy[,tmp_bloomy]
dim(bloomyDataExtrakt)

# To keep the old column names is a matter of safety.
old_col <- colnames(bloomyDataExtrakt)
for(i in 1:length(old_col)){
  index_of_old_in_list <- which(old_col[i] == relevantFields$Variable_BLOOMY)
  if(length(index_of_old_in_list) != 1){
    print(c(i, length(index_of_old_in_list)))
  }
  colnames(bloomyDataExtrakt)[i] <- relevantFields$commonName[index_of_old_in_list]
}

predictDataExtrakt <- predict[,tmp_predict]
dim(predictDataExtrakt)

# To keep the old column names is a matter of safety.
old_col <- colnames(predictDataExtrakt)

for(i in 1:length(old_col)){
  index_of_old_in_list <- which(old_col[i] == relevantFields$Variable_PREDICT)
  colnames(predictDataExtrakt)[i] <- relevantFields$commonName[index_of_old_in_list]
}

bloomyMissingFields <- relevantFields$Variable_PREDICT[which(relevantFields$MML_BLOOMY != "belegt")]
bloomyAddionalFields <- 
  data.frame(matrix(NA, nrow = dim(bloomyDataExtrakt)[1], ncol = length(bloomyMissingFields)))
colnames(bloomyAddionalFields) <- bloomyMissingFields
bloomyDataExtrakt <- cbind(bloomyDataExtrakt,bloomyAddionalFields)

# During the harmonization empty fields may be created.
predictMissingFields <- relevantFields$Variable_BLOOMY[which(relevantFields$MML_PREDICT != "belegt")]
predictAddionalFields <- 
  data.frame(matrix(NA, nrow = dim(predictDataExtrakt)[1], ncol = length(predictMissingFields)))
colnames(predictAddionalFields) <- predictMissingFields
predictDataExtrakt <- cbind(predictDataExtrakt,predictAddionalFields)

dim(predictDataExtrakt)
dim(bloomyDataExtrakt)

which(colnames(predictDataExtrakt) %nin% colnames(bloomyDataExtrakt))

# Just a check
which(table(colnames(predictDataExtrakt)) > 1)
which(table(colnames(bloomyDataExtrakt)) > 1)

# Now we have to rename some fields. This is dangerous but cannot be avoided.
old_predict_colnames <- colnames(predictDataExtrakt)

# i <- 191
n <- length(old_predict_colnames)
new_predict_colnames <- old_predict_colnames
for(i in 1:n){
  print(i)
  opc <- old_predict_colnames[i]
  
  tmp <- 
    relevantFields$Variable_BLOOMY[which(relevantFields$Variable_PREDICT == opc)]
  if(length(tmp) > 0){
    if(is.na(tmp) == FALSE){
      new_predict_colnames[i] <- tmp
    }
  }
}
colnames(predictDataExtrakt) <- new_predict_colnames

bloomyMissingFields <- 
  colnames(predictDataExtrakt)[which(colnames(predictDataExtrakt) %nin% colnames(bloomyDataExtrakt))]
bloomyAddionalFields <- 
  data.frame(matrix(NA, nrow = dim(bloomyDataExtrakt)[1], ncol = length(bloomyMissingFields)))
colnames(bloomyAddionalFields) <- bloomyMissingFields
bloomyDataExtrakt <- cbind(bloomyDataExtrakt,bloomyAddionalFields)

# Check! The number of columns should be equal.
dim(predictDataExtrakt)
dim(bloomyDataExtrakt)

#==========================================#
#    4. Write the data to a file.          #
#==========================================#

write.csv(predictDataExtrakt,
          paste(output_data_folder,"PredictData_Step01.csv",sep = ""),
          row.names = FALSE)
write.csv(bloomyDataExtrakt,
          paste(output_data_folder,"BloomyData_Step01.csv",sep = ""),
          row.names = FALSE)

