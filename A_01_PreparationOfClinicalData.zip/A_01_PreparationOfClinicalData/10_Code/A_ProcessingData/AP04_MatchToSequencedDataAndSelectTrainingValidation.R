# AP04

#===================================================#
#    This code does matches the harmonized, trans-  #
#    formed and selected data to the list of        #  
#    sequenced isolates.                            #                 
#===================================================#

library(readxl)
library(writexl)
library(Hmisc)
library(dplyr)

#==============================#
#    1. Reading the Data       #
#==============================#

path_I <-  
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/"
path_II <-
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_01_PreparationOfClinicalData/01_Data/00_InitialData/"
  #"P:/Sequencing_files_Staphaureus/"

input_data_folder <-  paste(path_I,
                            "A_01_PreparationOfClinicalData/01_Data/50_ProcessedData/",sep = "")

output_data_folder <-  paste(path_I,
                             "A_01_PreparationOfClinicalData/01_Data/50_ProcessedData/",sep = "")

output_inline_analysis <- paste(path_I,
                                "A_01_PreparationOfClinicalData/01_Data/20_InLineAnalysis/",sep = "")

Predict_StaphAur <- 
  read.csv(paste(input_data_folder,"SA_PredictData_Step03.csv",sep = ""))
Bloomy_StaphAur <- 
  read.csv(paste(input_data_folder,"SA_BloomyData_Step03.csv",sep = ""))


# Isolates that were sequenced
DataToBeSelected <- 
  read_xlsx(paste(path_II,"Saureus_Master-Isolateliste_BLOOMY-PREDICT_final_cohort_643_05092025.xlsx",sep = ""),
            sheet = "Masterliste S. aureus")

# Prepare the file for the in-line-analysis
ILA_file <- paste(output_inline_analysis,"ILA_Predict_MatchingWithSequencedIsolates.txt",sep = "")
if(file.exists(ILA_file)){
  file.remove(ILA_file)  
}else{
  file.create(ILA_file)
}

#=====================================================================#
#    2. Selection of data sets for isolates that were sequenced       #
#=====================================================================#

prd <- DataToBeSelected$studiso_id_mb

Predict_StaphAur <- 
  filter(Predict_StaphAur, studiso_id_mb %in% prd)
Bloomy_StaphAur <- 
  filter(Bloomy_StaphAur, studiso_id_mb %in% prd)

## reorder columns in Predict_StaphAur in order to get the identical data 
## structure 
tmp <- Predict_StaphAur[,colnames(Bloomy_StaphAur)]
colnames(tmp) == colnames(Bloomy_StaphAur)
Predict_StaphAur <- tmp

Bloomy_StaphAur$Source <- "BLOOMY"
tmp$Source <- "PREDICT"

StaphAur <- rbind(Bloomy_StaphAur, tmp)

write.table(x = "\nNumber of sequenced isolates:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = length(prd),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = "\nNumber of SA data sets from studies after matching with sequenced isolates:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(StaphAur)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = "\nNumber of SA data sets from studies after matching with sequenced isolates by study:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(StaphAur$Source),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#=====================================================================#
#    3. Correct three specific data sets                              #
#=====================================================================#

write.table(x = "\nFrequency of status (entl_ort_ent):",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = data.frame(table(StaphAur$entl_ort_ent, useNA = "always")),
            file = ILA_file,
            col.names = TRUE, row.names = FALSE, append = TRUE, quote = FALSE)

tmp <- which(is.na(StaphAur$entl_ort_ent))
if(length(tmp) > 0){
  write.table(x = "\nData set with missing status (entl_ort_ent):",
              file = ILA_file,
              col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
  write.table(x = StaphAur$id_fall[tmp],
              file = ILA_file,
              col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
}

# We know,that these participants survived the treatment of blood stream infection
# under consideration!
toBeCorrected <- c("RBL-17-315",
                   "RBL-18-246",
                   "RBL-18-402")

tmp <- which(StaphAur$id_fall %in% toBeCorrected)

if(length(tmp) > 0){
  StaphAur$entl_ort_ent[tmp] <- "corrected to entlassen"
}

write.table(x = "\nFrequency of status (entl_ort_ent) after correction:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = data.frame(table(StaphAur$entl_ort_ent, useNA = "always")),
            file = ILA_file,
            col.names = TRUE, row.names = FALSE, append = TRUE, quote = FALSE)

#=====================================================================#
#    3. Divide into training and validation data sets -- by index     #
#=====================================================================#
StaphAur$TrainingData <- 1
set.seed(2589)
Val_Indices <- sample(dim(StaphAur)[1],round(dim(StaphAur)[1]/4,0))
StaphAur$TrainingData[Val_Indices] <- 0
#
# just check!
dim(StaphAur)[1] == dim(Bloomy_StaphAur)[1] + dim(Predict_StaphAur)[1]

write.table(x = "\nNumber of SA data sets from studies after matching with sequenced isolates by study:\n\tby type (0: Validation, 1: Training):",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(StaphAur$Source,StaphAur$TrainingData),
            file = ILA_file,
            col.names = TRUE, row.names = TRUE, append = TRUE, quote = FALSE)

write.csv(StaphAur,
          paste(output_data_folder,"SA_Data_Step04.csv",sep = ""),
          row.names = FALSE)

