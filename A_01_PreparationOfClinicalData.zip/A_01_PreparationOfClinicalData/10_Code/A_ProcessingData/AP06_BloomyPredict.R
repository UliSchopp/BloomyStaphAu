# AP06

library(readxl)
library(writexl)
library(tidyr)

#=======================================================#
#    This code calculates 'appropriateness' of therapy   #                 
#=======================================================#

#==============================#
#    1. Reading the Data       #
#==============================#

path_I <-  
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/"

path_II <-
  "P:\\clinical_database\\"

input_data_folder <-  paste(path_I,
                            "A_01_PreparationOfClinicalData/01_Data/50_ProcessedData/",sep = "")

output_data_folder <-  paste(path_I,
                             "A_01_PreparationOfClinicalData/01_Data/50_ProcessedData/",sep = "")

output_inline_analysis <- paste(path_I,
                                "A_01_PreparationOfClinicalData/01_Data/20_InLineAnalysis/",sep = "")

output_public_analysis <- paste(path_I,
                                "A_01_PreparationOfClinicalData/01_Data/70_AnalysisAndOverviews/",sep = "")

additional_data_folder <- paste(path_I,"A_01_PreparationOfClinicalData/01_Data/00_InitialData/", sep = "")

SelectedData <- 
  read.csv(paste(input_data_folder,"SA_Data_Step05.csv",sep = ""))

# 
# read Antibiogram data

Antibiogramme_1 <- 
  read_xlsx(
    paste(path_II,
          "Database_webkess_for_antimicrobial_testing_of_BLOOMY_isolates_20220114_duplicats_deleted.xlsx",
          sep = ""),
    sheet = 1)

Antibiogramme_2 <- 
  read_xlsx(
    paste(path_II,
          "Database_webkess_for_antimicrobial_testing_of_BLOOMY_isolates_20220114_duplicats_deleted.xlsx",
          sep = ""),
    sheet = 2)

#======================================#
#    2. Prepare antibiogram data       #
#======================================#

# check antibiogram data schemes
length(which(colnames(Antibiogramme_1) != colnames(Antibiogramme_2))) == 0

# put data together
Antibiogramme <- rbind(Antibiogramme_1,Antibiogramme_2)


# create extended study number (again)

extend_StudyIsoNumber <- function(x){
  xx <- unlist(strsplit(x, "-"))
  if(length(xx) == 4){
    if(nchar(xx[3]) == 3){
      nx <- paste(xx[1],"-",xx[2],"-0",xx[3],"-",xx[4],sep = "")
      return(nx)}else{
        nx <- x
        return(nx)}
  }else{
    if(nchar(xx[3]) == 3){
      nx <- paste(xx[1],"-",xx[2],"-0",xx[3],sep = "")
      return(nx)}else{
        nx <- x
        return(nx)}
  }
}
# check that code
extend_StudyIsoNumber(SelectedData$studiso_id_mb[1])
extend_StudyIsoNumber(SelectedData$studiso_id_mb[2])
extend_StudyIsoNumber(SelectedData$studiso_id_mb[555])


#==================================#
#    3. First calculation step     #
#==================================#

SelectedData$Extended_studiso_id <- NA
rowCont <- 555
for(rowCont in 1:dim(SelectedData)[1]){
  if(is.na(SelectedData$err1_gram_pos_mb[rowCont]) == FALSE & 
     is.na(SelectedData$studiso_id_mb[rowCont]) == FALSE &
     SelectedData$err1_gram_pos_mb[rowCont] == "Staphylococcus aureus"){
    SelectedData$Extended_studiso_id[rowCont] <- 
      extend_StudyIsoNumber(SelectedData$studiso_id_mb[rowCont])}else{#Isolat 2 enthaelt Staph. Aur.
        if(is.na(SelectedData$err2_gram_pos_mb[rowCont]) == FALSE & 
           is.na(SelectedData$e2_studiso_id_mb[rowCont]) == FALSE &
           SelectedData$err2_gram_pos_mb[rowCont] == "Staphylococcus aureus"){     
          SelectedData$Extended_studiso_id[rowCont] <- 
            extend_StudyIsoNumber(SelectedData$e2_studiso_id_mb[rowCont])
        }else{
          SelectedData$Extended_studiso_id[rowCont] <- "moeglicherweise keine Iso-Nummer angegeben"
        }
      }
}

Antibiogramme$Extended_studiso_id <- NA

for(rowCont in 1:dim(Antibiogramme)[1]){
  Antibiogramme$Extended_studiso_id[rowCont] <- 
    extend_StudyIsoNumber(Antibiogramme$BSI_StudyIsolateNumber[rowCont])
}

SelectedData$Verstorben <- ifelse(SelectedData$entl_ort_ent == "Im Krankenhaus verstorben", 1, 0)

#===================================#
#    4. Second calculation step     #
#===================================#

SelectedData$appropriateness <- NA
SelectedData$numberIsolatedSA <- NA
SelectedData$SpeciesOneCase <- NA
SelectedData$Comment <- NA


NN <- dim(SelectedData)[1]
#i_case <- 376

for(i_case in 1:NN){
  #print(i_case)
  CurrCase <- SelectedData[i_case,]
  
  ### Das Antibiogramm dazu suchen
  CurrAB <- 
    Antibiogramme[which(toupper(Antibiogramme$Extended_studiso_id) == 
                          toupper(CurrCase$Extended_studiso_id)),]
  
  if(dim(CurrAB)[1] > 0){# Mindestens ein Fall wurde gefunden
    
    tmp <- which(CurrAB$BSI_Species == "Staphylococcus_aureus")
    SelectedData$numberIsolatedSA[i_case] <- length(tmp)
    
    if(length(tmp) == 0){#nur Info!
      SelectedData$SpeciesOneCase[i_case] <- CurrAB$BSI_Species 
    }
    
    if(length(tmp) == 1){  
      
      CurrAB <- CurrAB[tmp,]  
      ### Die Sensitivitätsattribute suchen
      
      ExtractCurrAB <- 
        CurrAB[c(
          "CaseId",
          "PatientId",
          "BSI_Species",
          "BSI_ExciterAttribut",
          "BSI_Antibiogram_LINEZOLID_SIR",	
          "BSI_Antibiogram_LINEZOLID_MHK",
          "BSI_Antibiogram_LINEZOLID_MHKOther",
          "BSI_Antibiogram_OXACILLIN_SIR",
          "BSI_Antibiogram_OXACILLIN_MHK",
          "BSI_Antibiogram_OXACILLIN_MHKOther",
          "BSI_Antibiogram_VANCOMYCIN_SIR",
          "BSI_Antibiogram_VANCOMYCIN_MHK",
          "BSI_Antibiogram_VANCOMYCIN_MHKOther",
          "BSI_Antibiogram_PIPERACILLIN_SIR",	
          "BSI_Antibiogram_PIPERACILLIN_MHK",	
          "BSI_Antibiogram_PIPERACILLIN_MHKOther")]
      
      ### Berechnung der Merkmalsfelder, die 
      ### die Behandlungen mit Antibiotikaklassen aufnehmen
      abt_colnames    <- grep("_abt",colnames(CurrCase))
      verabt_colnames <- grep("_verab_abt",colnames(CurrCase))
      abt_colnames    <- setdiff(abt_colnames, verabt_colnames)
      
      if("Vancomycin" %in% CurrCase[abt_colnames] ){
        TREAT_Vanc <- TRUE }else{ TREAT_Vanc <- FALSE }
      
      if("Daptomycin" %in% CurrCase[abt_colnames]){
        TREAT_Dapt <- TRUE }else{ TREAT_Dapt <- FALSE }
      
      # zum Testen: if("Vancomycin" %in% CurrCase[abt_colnames]){print(i_case)}
      
      # Set Vancomycin.is.iv to FALSE in order to initialize the variable!
      Vancomycin.is.iv <- FALSE
      
      if("Vancomycin" %in% CurrCase[abt_colnames]){
        # What are the specific name of that column, containing the 
        # Vancomycin entry?
        vanco_col_name <- 
          colnames(CurrCase)[abt_colnames[which(CurrCase[abt_colnames] == 
                                                  "Vancomycin")]]
        
        number_of_vanco_cols <- length(vanco_col_name)
        
        curr_vanco <- 1
        for(curr_vanco in 1:number_of_vanco_cols){
          curr_vanco_col_name <- vanco_col_name[curr_vanco]
          
          # Extract the first few letters
          length_vanco_col_name <- nchar(curr_vanco_col_name)
          first_letters <- 
            substr(curr_vanco_col_name,1,(length_vanco_col_name - 4))
          
          # Find the treatment column!
          colindex_of_treatment <- 
            which(colnames(CurrCase) == 
                    paste(first_letters,"_verab_abt", sep = ""))
          
          is.iv <- CurrCase[colindex_of_treatment]
          
          # Sometimes there's no info about treatment:
          # We set it is.iv to "NO"!
          if(is.na(is.iv)){
            is.iv <- "NO"
            SelectedData$Comment[i_case] <- 
              paste(SelectedData$Comment[i_case],
                    "Vancomycin applied, but no details given.")
          }
          
          # To avoid trouble: Only if has never been set to TRUE befor for this
          # specific case, check the iv status!
          if(is.iv == 1 & Vancomycin.is.iv == FALSE){
            Vancomycin.is.iv <- TRUE
          }
        }
      }
      
      if("Linezolid" %in% CurrCase[abt_colnames]){
        TREAT_Line <- TRUE }else{ TREAT_Line <- FALSE }
      
      if("Piperacillin+Tazobactam"%in% CurrCase[abt_colnames]){
        TREAT_PipTaz <- TRUE }else{ TREAT_PipTaz <- FALSE } 
      
      if("Amoxicillin+ Clavulansäure"  %in% CurrCase[abt_colnames] |
         "Ampicillin+Sulbactam" %in% CurrCase[abt_colnames] |
         "Cefazolin" %in% CurrCase[abt_colnames] |
         "Flucloxacillin" %in% CurrCase[abt_colnames]){
        TREAT_OxacAliase  <- TRUE }else{ TREAT_OxacAliase  <- FALSE }
      
      appropriate <- NA
      
      if(ExtractCurrAB$BSI_ExciterAttribut == "MRSA"){
        if((ExtractCurrAB$BSI_Antibiogram_VANCOMYCIN_SIR == "S" & 
            TREAT_Vanc == TRUE & 
            Vancomycin.is.iv == TRUE) | 
           (ExtractCurrAB$BSI_Antibiogram_VANCOMYCIN_SIR == "S" & 
            TREAT_Dapt == TRUE) |
           (ExtractCurrAB$BSI_Antibiogram_LINEZOLID_SIR == "S" & 
            TREAT_Line == TRUE)){
          appropriate <- TRUE }else{ appropriate <- FALSE }
      }else{
        if((ExtractCurrAB$BSI_Antibiogram_VANCOMYCIN_SIR == "S" & 
            TREAT_Vanc == TRUE & Vancomycin.is.iv == TRUE) | 
           (ExtractCurrAB$BSI_Antibiogram_VANCOMYCIN_SIR == "S" & 
            TREAT_Dapt == TRUE) |
           (ExtractCurrAB$BSI_Antibiogram_LINEZOLID_SIR == "S" & 
            TREAT_Line == TRUE) |
           (TREAT_PipTaz == TRUE) |
           (ExtractCurrAB$BSI_Antibiogram_OXACILLIN_SIR == "S" & 
            TREAT_OxacAliase == TRUE)){
          appropriate <- TRUE }else{ appropriate <- FALSE } 
      }
      SelectedData$appropriateness[i_case] <- appropriate
    }else{# mehr als ein Fall wurde gefunden
      SelectedData$appropriateness[i_case] <- 
        paste("Mehr als ein Fall:",dim(CurrAB)[1])}
  }else{# Kein Fall wurde gefunden!
    SelectedData$appropriateness[i_case] <- "Kein Fall gefunden."}
}

# some documentation

appness <- data.frame(table(SelectedData$appropriateness, useNA = "always"))
colnames(appness) <- c("Appropriate","counts")
write_xlsx(appness,
      paste(output_public_analysis,"AppropriatenessValues.xlsx", sep =""))

appnessByCentre <- 
  data.frame(table(SelectedData[,c("appropriateness","centre")]))
appnessByCentre <-pivot_wider(appnessByCentre, names_from = "centre", values_from = "Freq")
write_xlsx(appnessByCentre,
           paste(output_public_analysis,"AppropriatenessValuesByCentre.xlsx", sep =""))

#===================================#
#    5. BSI_MRSA                    #
#===================================#

SelectedData$BSI_MRSA <- NA

NN <- dim(SelectedData)[1]
i_case <- 450

for(i_case in 1:NN){
  CurrCase <- SelectedData[i_case,]
  
  ### Das Antibiogramm dazu suchen
  CurrAB <- 
    Antibiogramme[which(toupper(Antibiogramme$Extended_studiso_id) == 
                          toupper(CurrCase$Extended_studiso_id)),]
  if(dim(CurrAB)[1] > 0){# Mindestens ein Fall wurde gefunden
    SelectedData$BSI_MRSA[i_case] <- CurrAB$BSI_ExciterAttribut
  }
}

#==============================================#
#    6. Appropriateness by data inspection     #
#==============================================#

inappropriate_cases <-
  read_excel(paste(additional_data_folder ,"Unappropriate_cases_BLOOMY+PREDICT_643.xlsx",sep = ""))

inappropriate_cases <- data.frame(inappropriate_cases)
SelectedData$appropriatenessByInspection <- TRUE
SelectedData$Extended_studiso_id_Short <- substr(SelectedData$Extended_studiso_id,1,11)
indices_inappropriate <-
  which(SelectedData$Extended_studiso_id_Short %in% inappropriate_cases$id_fall)
SelectedData$appropriatenessByInspection[indices_inappropriate] <- FALSE

appness <- data.frame(table(SelectedData$appropriatenessByInspection, useNA = "always"))
colnames(appness) <- c("Appropriate","counts")
write_xlsx(appness,
           paste(output_public_analysis,"AppropriatenessByInspectionValues.xlsx", sep =""))

write.csv(SelectedData,
          paste(output_data_folder,"SA_Data_Step06.csv",sep = ""),
          row.names = FALSE)


