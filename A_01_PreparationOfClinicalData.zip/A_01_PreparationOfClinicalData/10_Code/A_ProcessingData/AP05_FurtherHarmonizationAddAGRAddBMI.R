# AP05

#===================================================#
#    This code harmonizes again some fields         #                 
#===================================================#

library(Hmisc)
library(dplyr)
library(readxl)

#==============================#
#    1. Reading the Data       #
#==============================#

path_I <-  
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/"
path_II <-
  "S:/250905_Bioinformatics_Reanalysis/"

input_data_folder <-  paste(path_I,
                            "A_01_PreparationOfClinicalData/01_Data/50_ProcessedData/",sep = "")

output_data_folder <-  paste(path_I,
                             "A_01_PreparationOfClinicalData/01_Data/50_ProcessedData/",sep = "")

output_inline_analysis <- paste(path_I,
                                "A_01_PreparationOfClinicalData/01_Data/20_InLineAnalysis/",sep = "")

output_public_analysis <- paste(path_I,
                                "A_01_PreparationOfClinicalData/01_Data/70_AnalysisAndOverviews/",sep = "")

StaphDaten <- 
  read.csv(
    paste(input_data_folder,
          "SA_Data_Step04.csv", 
          sep = ""))
StaphDaten <- data.frame(StaphDaten)

predict_indices <- which(StaphDaten$Source == "PREDICT")
bloomy_indices <- which(StaphDaten$Source == "BLOOMY")

#==============================#
#    2. Harmonization          #
#==============================#

# harmonize nos_mb
# ================
StaphDaten$nos_mb[predict_indices] <- 
  ifelse(StaphDaten[predict_indices,]$nos_amb_mb == "nosokomial erworben", "ja", "nein")

# harmonize MRSA
# ==============
StaphDaten$MRSA_harmonized <- NA
StaphDaten$MRSA_harmonized[bloomy_indices] <- 
  StaphDaten$err1_mrsa_mb_[bloomy_indices]

StaphDaten$MRSA_harmonized[predict_indices] <- 
  StaphDaten$e1_mrsa_mb_[predict_indices]
table(StaphDaten$MRSA_harmonized,useNA = "always")

# harmonize GPT_ALT0
# ==================
StaphDaten$GPT_ALT0_harmonized <- NA
StaphDaten$GPT_ALT0_harmonized[bloomy_indices] <- 
  StaphDaten$GPT_ALT0[bloomy_indices]

StaphDaten$GPT_ALT0_harmonized[predict_indices] <- 
  StaphDaten$GPT_ALTt0[predict_indices]
#table(StaphDaten$GPT_ALT0_harmonized,useNA = "always")
#table(filter(StaphDaten, is.na(StaphDaten$GPT_ALT0_harmonized))$Source)

# harmonize the focus data!
# =========================
StaphDaten$focus_harmonized <- "keine Angabe"
StaphDaten$focus_harmonized[predict_indices] <-
  StaphDaten$fokus1_bsi_ent[predict_indices]
#unique(StaphDaten$fokus1_bsi_ent[predict_indices])

#
#codedfocus1	  Abdominell fokus => "abdominell"
#codedfocus1_1	Abdominell_fremdkörper => "abdominell; Fremdkörper"
#codedfocus2	  Respiratorisch => "respiratorisch" 
#codedfocus2_1  Respiratiorisch_fremdkörper =>  "respiratorisch; Fremdkörper"
#codedfocus3	  Urogenital => "urogenital"
#codedfocus3_1	Urogenital_fremdkörper => "urogenital; Fremdkörper" 
#codedfocus4	  kardiovaskulär => "kardiovaskulär" 
#codedfocus4_1	kardiovaskulär_fremdkörper => "kardiovaskulär; intravasale Fremdkörper"

#codedfocus6	  Haut, Weichteil, Gewebe => "Haut, Weichteile"
#codedfocus6_1	Haut, Weichteil, Knochen, Gewebe_fremdkörper => "Haut, Weichteile; Fremdkörper"
#codedfocus7	  zentralen Nervensystem => "ZNS" 
#codedfocus7_1	zentralen Nervensystem_fremdkörper => "ZNS; Fremdkörper"
#codedfocus8	  Aplasie ohne fokus
#codedfocus9	  Knochen, Gelenke => "Knochen, Gelenke"
#codedfocus9_1	Knochen, Gelenke_fremdkörper => "Knochen, Gelenke; Fremdkörper"

tmp <- which(StaphDaten$codedfocus1 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <- "abdominell" 
}
tmp <- which(StaphDaten$codedfocus1_1 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <- "abdominell; Fremdkörper" 
}
tmp <- which(StaphDaten$codedfocus2 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <- "respiratorisch" 
}
tmp <- which(StaphDaten$codedfocus2_1 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <- "respiratorisch; Fremdkörper" 
}
tmp <- which(StaphDaten$codedfocus3 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "urogenital"  
}
tmp <- which(StaphDaten$codedfocus3_1 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "urogenital; Fremdkörper"  
}
tmp <- which(StaphDaten$codedfocus4 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "kardiovaskulär"  
}
tmp <- which(StaphDaten$codedfocus4_1 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "kardiovaskulär; intravasale Fremdkörper"  
}
tmp <- which(StaphDaten$codedfocus5 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "keine Angabe" 
}
tmp <- which(StaphDaten$codedfocus5_1 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "keine Angabe"  
}
tmp <- which(StaphDaten$codedfocus6 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "Haut, Weichteile" 
}
tmp <- which(StaphDaten$codedfocus6_1 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "Haut, Weichteile; Fremdkörper"  
}
tmp <- which(StaphDaten$codedfocus7 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "ZNS" 
}
tmp <- which(StaphDaten$codedfocus7_1 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "ZNS; Fremdkörper"  
}
tmp <- which(StaphDaten$codedfocus8 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "andere" 
}
tmp <- which(StaphDaten$codedfocus8_1 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "andere" 
}
tmp <- which(StaphDaten$codedfocus9 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "Knochen, Gelenke" 
}
tmp <- which(StaphDaten$codedfocus9_1 == 1)
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "Knochen, Gelenke; Fremdkörper"  
}
# Default-Wert "keine Angabe" wird aus den PREDICT Daten in einem Fall mit NA
# überschrieben....
tmp <- which(is.na(StaphDaten$focus_harmonized))
if(length(tmp) > 0){
  StaphDaten$focus_harmonized[tmp] <-  "keine Angabe"  
}
#table(StaphDaten$focus_harmonized,useNA = "always")

#table(filter(StaphDaten, Source == "BLOOMY")$focus_harmonized)


#==============================================#
#    3. Enrichment ... by agr type             #
#==============================================#
# load Agr-Typ 
# ============
AgrTypData <- 
  read_xlsx(paste(path_II,
                   "2025-09-03_bactopia-report_modified_ver1.xlsx", sep = ""),
            skip = 1)
AgrTypData[1:2,]
AgrTypData <- data.frame(AgrTypData)
wht <-
  which(colnames(AgrTypData) %in% 
                          c("sample",
                            "agr_group",	
                            "match_score",	
                            "canonical_agrD"))

## create extended study number (again)

extend_StudyIsoNumber <- function(x){
  xx <- unlist(strsplit(x, "-"))
  if(length(xx) == 4){
    if(nchar(xx[3]) == 3){
      nx <- paste(xx[1],"-",xx[2],"-0",xx[3],"-",xx[4],sep = "")
      return(nx)}else{
        nx <- x
        return(nx)}
  }else{
    if(nchar(xx[3]) == 3){
      nx <- paste(xx[1],"-",xx[2],"-0",xx[3],sep = "")
      return(nx)}else{
        nx <- x
        return(nx)}
  }
}
# check that code
extend_StudyIsoNumber(StaphDaten$studiso_id_mb[1])
extend_StudyIsoNumber(StaphDaten$studiso_id_mb[2])
extend_StudyIsoNumber(StaphDaten$studiso_id_mb[555])

StaphDaten$studiso_id_mb_extended <- 
  sapply(StaphDaten$studiso_id_mb,extend_StudyIsoNumber)

StaphDaten <-
  merge(x = StaphDaten,
        y = AgrTypData[,c("agr_group","sample")],
        by.x = "studiso_id_mb_extended", 
        by.y = "sample")

write_xlsx(
  x = data.frame(table(StaphDaten$agr_group, useNA = "always")),
  path = paste(output_public_analysis,"AGR_Goups.xlsx",sep = "")
)

#==============================================#
#    3. Enrichment ... by BMI                  #
#==============================================#

# Calulate BMI
# ============
# m/(l*l) 
# m: mass in kg
# l: height in m
# k_gewicht_t3 was recorded in kg
# k_gre1_t3 was recorded in cm
# StaphDaten$k_gewicht1_t3
# StaphDaten$k_gre1_t3

StaphDaten$BMI <- StaphDaten$k_gewicht1_t3/StaphDaten$k_gre1_t3^2 * 10000

# Check
pdf(paste(output_inline_analysis,"BMI.pdf",sep = ""))
  hist(StaphDaten$BMI)
dev.off()

write.csv(StaphDaten,
          paste(output_data_folder,"SA_Data_Step05.csv",sep = ""),
          row.names = FALSE)
