# AP02

#===================================================#
#    This code does some data transformation.       #
#    Due to different data models for the studies   #
#    we decided to code the data transformations in #
#    specific files.                                #                    
#===================================================#

library(readxl)
library(writexl)
library(Hmisc)
library(dplyr)

#==============================#
#    1. Reading the Data       #
#==============================#

source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_01_PreparationOfClinicalData/01_Data/10_ControlFiles/ControlFile.R")

#path_I <-  "Q:/NAS/BLOOMY_II/DataAnalysis/01_CombinedClinicalGeneticModel/"
#
#input_data_folder <-  paste(path_I,
#                            "A_PreparationOfClinicalData/01_Data/50_ProcessedData/",sep = "")
##field_list_folder <- "P:/DataAnalysis/11_ExtractRelevantData/"
#output_data_folder <-  paste(path_I,
#                             "A_PreparationOfClinicalData/01_Data/50_ProcessedData/",sep = "")


bloomyDataExtrakt <-
read.csv(paste(output_data_folder,"BloomyData_Step01.csv",sep = ""), 
         header = TRUE)

# Prepare the file for the in-line-analysis
ILA_file <- paste(output_inline_analysis,"ILA_Bloomy_DataTransformation.txt",sep = "")
if(file.exists(ILA_file)){
  file.remove(ILA_file)  
}else{
  file.create(ILA_file)
}

#=================================#
#    2. Data Transformation       #
#=================================#

#    2.1 Sex
#    -------
bloomyDataExtrakt$sex_mb <-
  ifelse(bloomyDataExtrakt$sex_mb___0 == "Checked" & bloomyDataExtrakt$sex_mb___1 == "Unchecked","weiblich",
         ifelse(bloomyDataExtrakt$sex_mb___0 == "Unchecked" & bloomyDataExtrakt$sex_mb___1 == "Checked","männlich","zweifelhaft"))

write.table(x = "BLOOMY data transformation for sex.\n===================================\n\nCounts before transformation:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
write.table(x = table(bloomyDataExtrakt$sex_mb, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)


existing_info_sex <- filter(bloomyDataExtrakt, sex_mb %in% c("männlich","weiblich"))$sex_mb

# "zweifelhaft" (= doubtful) will be transformed to either "männlich" or "weiblich".
# To avoid problems we impute by sampling from the data sets with known sex.
# As a check, we calculate the sex ratios before and after transformation.

write.table(x = "\nRatio of counts before transformation:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = round(table(existing_info_sex)/length(existing_info_sex),4),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

# Find the data set with sex = "zweifelhaft"
ind_no_inf <- 
  which(bloomyDataExtrakt$sex_mb == "zweifelhaft") 

# Impute 
set.seed(18982)
imputation <- sample(x = existing_info_sex, size = length(ind_no_inf), replace = TRUE )
table(imputation)/length(imputation)

bloomyDataExtrakt$sex_mb[ind_no_inf] <- imputation

write.table(x = "\nCounts after transformation:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
write.table(x = table(bloomyDataExtrakt$sex_mb, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
existing_info_sex <- filter(bloomyDataExtrakt, sex_mb %in% c("männlich","weiblich"))$sex_mb

write.table(x = "\nRatio of counts after transformation:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = round(table(existing_info_sex)/length(existing_info_sex),4),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#    2.2 Age
#    -------

# We have to calculate the age!
bloomyDataExtrakt$age_aufstat <- as.numeric(substr(bloomyDataExtrakt$aufstat_k_mb,1,4)) - bloomyDataExtrakt$gebj_mb

write.table(x = "\nDistribution of Age:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(cut(bloomyDataExtrakt$age_aufstat,breaks = seq(15,105,5))),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#    2.3 Temperature
#    ---------------
write.table(x = "\nDistribution of temperature before transformation:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_temp_t0, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

# Imputation 1:
# In some cases the temperature was measured differntly. 
# This information is stored in pbs_temp_ort_t0.
# So we use that -- if possible -- when data were missing.

bloomyDataExtrakt$pbs_temperature <- 
  bloomyDataExtrakt$pbs_temp_t0
missing_temperature_indizes <- 
  which(bloomyDataExtrakt$pbs_temperature == "unbekannt" | is.na(bloomyDataExtrakt$pbs_temperature))
bloomyDataExtrakt$pbs_temperature[missing_temperature_indizes] <- 
  bloomyDataExtrakt$pbs_temp_ort_t0[missing_temperature_indizes]
write.table(x = "\nDistribution of temperature after imputation from other place:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_temperature, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

# Imputation 2:
# other missing data were imputed by "36,1-38,9°C"
missing_temperature_indizes <- 
  which(bloomyDataExtrakt$pbs_temperature == "unbekannt" |
          is.na(bloomyDataExtrakt$pbs_temperature))
bloomyDataExtrakt$pbs_temperature[missing_temperature_indizes] <- "36,1-38,9øC"
table(bloomyDataExtrakt$pbs_temperature)
write.table(x = "\nDistribution of temperature after imputation by default value:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_temperature, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

# Recoding by 0, 1, 2
recode_temperature <-  function(x){
  switch(x, 
         "=< 35øC oder >= 40øC"={return(2)},
         "35,1-36,0øC oder 39,0-39,9øC" = {return(1)},
         "36,1-38,9øC" = {return(0)},
         {return(0)}
  )
}
# Checks
recode_temperature("36,1-38,9øC") == 0
recode_temperature("35,1-36,0øC oder 39,0-39,9øC") == 1
recode_temperature("=< 35øC oder >= 40øC") == 2

bloomyDataExtrakt$pbs_recoded_temperature <- sapply(bloomyDataExtrakt$pbs_temperature, FUN = recode_temperature)

write.table(x = "\nDistribution of recoded temperature:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_recoded_temperature, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#    2.4 hypotension
#    ----------------
write.table(x = "\nDistribution hypotension before transformation (yes/no):",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_hypo_t0, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

recode_hypotension <-  function(x){
  switch(x, 
         "ja"={return(2)},
         "nein" = {return(0)},
         {return(0)}
  )
}
# Checks
recode_hypotension("ja") == 2
recode_hypotension("nein") == 0
recode_hypotension("unbekannt") == 0

bloomyDataExtrakt$pbs_recoded_hypotension <- sapply(bloomyDataExtrakt$pbs_hypo_t0, FUN = recode_hypotension)

write.table(x = "\nDistribution hypotension after transformation (yes/no):",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_recoded_hypotension, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#    2.5 mechanical ventilation
#    --------------------------
write.table(x = "\nDistribution mechanical ventilation before transformation (yes/no):",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_mbea_t0, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

recode_mechvent <-  function(x){
  switch(x, 
         "ja"={return(2)},
         "nein" = {return(0)},
         {return(0)}
  )
}
# Checks
recode_mechvent("ja") == 2
recode_mechvent("nein") == 0
recode_mechvent("unbekannt") == 0

bloomyDataExtrakt$pbs_recoded_mechvent <- sapply(bloomyDataExtrakt$pbs_mbea_t0, FUN = recode_mechvent)

write.table(x = "\nDistribution mechanical ventilation after transformation (yes/no):",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_recoded_mechvent, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#    2.6 cardial arrest
#    ------------------
write.table(x = "\nDistribution cardial arrest before transformation (yes/no):",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_hks_t0, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

recode_cardarrest <-  function(x){
  switch(x, 
         "ja"={return(4)},
         "nein" = {return(0)},
         {return(0)}
  )
}
# Checks
recode_cardarrest("ja") == 4
recode_cardarrest("nein") == 0
recode_cardarrest("unbekannt") == 0

bloomyDataExtrakt$pbs_recoded_hks <- sapply(bloomyDataExtrakt$pbs_hks_t0, FUN = recode_cardarrest)

write.table(x = "\nDistribution cardial arrest after transformation (yes/no):",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_recoded_hks, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#    2.7 mental status
#    -----------------
write.table(x = "\nDistribution mental status before transformation:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_mz_t0, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

bloomyDataExtrakt$pbs_mz_t0 <- substr(bloomyDataExtrakt$pbs_mz_t0,1,4)

recode_mentalStatus <-  function(x){
  switch(x, 
         "koma"={return(4)},
         "apat"={return(2)},
         "deso"={return(1)},
         "wach" = {return(0)},
         {return(0)}
  )
}
# Checks
recode_mentalStatus("koma") == 4
recode_mentalStatus("apat") == 2
recode_mentalStatus("deso") == 1
recode_mentalStatus("wach") == 0
recode_mentalStatus("unbe") == 0

bloomyDataExtrakt$pbs_recoded_mz <- sapply(bloomyDataExtrakt$pbs_mz_t0, FUN = recode_mentalStatus)
table(bloomyDataExtrakt$pbs_recoded_mz,bloomyDataExtrakt$pbs_mz_t0)

write.table(x = "\nDistribution mental status after transformation:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_recoded_mz, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#    2.8 pbs score
#    -----------------
bloomyDataExtrakt$pbs_t0 <- 
  bloomyDataExtrakt$pbs_recoded_temperature + 
  bloomyDataExtrakt$pbs_recoded_hypotension +
  bloomyDataExtrakt$pbs_recoded_mechvent +
  bloomyDataExtrakt$pbs_recoded_hks +
  bloomyDataExtrakt$pbs_recoded_mz
write.table(x = "\nDistribution of pbs score:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$pbs_t0, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)


#==========================================#
#    3. analysis of discharge status       #
#==========================================#
write.table(x = "\nDistribution of discharge status:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$entl_ort_ent, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)


g_0 <- filter(bloomyDataExtrakt,entl_ort_ent == "Im Krankenhaus verstorben")$pbs_t0
g_1 <- filter(bloomyDataExtrakt,entl_ort_ent != "Im Krankenhaus verstorben")$pbs_t0

pdf(file = paste(output_inline_analysis,"Bloomy_PBS_versus_Status.pdf",sep = ""))
boxplot(g_0,
        g_1, 
        main = "BLOOMY: pbs for died versus survived",
        names = c("died","surived"),
        ylab = "pbs score")
dev.off()

## ---------------------------------------------------------------------------------------------------------------------
df <- data.frame(
  groups = c(rep("died",length(as.vector(table(g_0)))),
             rep("surv",length(as.vector(table(g_1))))),
  score = c(1:length(as.vector(table(g_0))),1:length(as.vector(table(g_1)))),
  values = c(as.vector(table(g_0)), as.vector(table(g_1))))
df <- tidyr::spread(df, groups, values)

if(length(is.na(df$surv)) >0){
  df$surv[which(is.na(df$surv))] <- 0
}
if(length(is.na(df$died)) >0){
  df$died[which(is.na(df$died))] <- 0
}

write.table(x = "\nDistribution of pbs by discharge status:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = df,
            file = ILA_file,
            col.names = TRUE, row.names = FALSE, append = TRUE, quote = FALSE)

# chi-square test
M <- as.table(rbind(df$died, df$surv))

dimnames(M) <- list(group = c("died","survived"), score = 1:dim(M)[2])
cqt <- chisq.test(M)
write.table(x = "\nchi-square test for null hypthesis of 'no diference':",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
write.table(x = "\n   p-value:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
write.table(x = round(cqt$p.val,4),
            file = ILA_file,
            col.names = TRUE, row.names = FALSE, append = TRUE, quote = FALSE)
write.table(x = "\n   degrees of freedom:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
write.table(x = cqt$parameter,
            file = ILA_file,
            col.names = TRUE, row.names = FALSE, append = TRUE, quote = FALSE)

# calculation of chi-square test statistic by hand ...
df$n_dot_j <- df$died+df$surv
n_died_dot <- sum(df$died) 
n_surv_dot <- sum(df$surv) 
n_total    <- n_died_dot + n_surv_dot
df$exp_died <- df$n_dot_j * n_died_dot/n_total
df$exp_surv <- df$n_dot_j * n_surv_dot/n_total

(test_value <- sum((df$died-df$exp_died)^2/df$exp_died) + sum((df$surv-df$exp_surv)^2/df$exp_surv) )

#=================#
#    4. CCI       #
#=================#

assess_age <-function(x){
  if(x <= 59){return(1)}else{
    if(x <= 69){return(2)}else{
      if(x <= 79){return(3)}else{
        if(x <= 89){return(4)}else{
          return(5)
        }
      }
    }
  }}
#checks
testdf <- data.frame(
  age = seq(40,105,5),
  score =sapply(seq(40,105,5), assess_age))
testdf


bloomyDataExtrakt$CCI_age_score <- sapply(bloomyDataExtrakt$age_aufstat, assess_age)



x <- bloomyDataExtrakt[1,]
calculate_CCI <- function(x){
  ifelse(is.na(x$herzinf_t0) == FALSE & x$herzinf_t0 == "ja",1,0) +
    ifelse(is.na(x$herzinsuff_t0) == FALSE & x$herzinsuff_t0 == "ja",1,0) +
    ifelse(is.na(x$peri_ater_verschl_t0) == FALSE & x$peri_ater_verschl_t0 == "ja",1,0) +
    ifelse(is.na(x$demenz_t0) == FALSE & x$demenz_t0 == "ja",1,0) +
    ifelse(is.na(x$cerebrovas_erk_t0) == FALSE & x$cerebrovas_erk_t0 == "ja",1,0) +  
    ifelse(is.na(x$chron_lungerk_t0) == FALSE & x$chron_lungerk_t0 == "ja",1,0) +  
    ifelse(is.na(x$kollagenose_t0) == FALSE & x$kollagenose_t0 == "ja",1,0) +
    ifelse(is.na(x$gdulkuskrankheit_t0) == FALSE & x$gdulkuskrankheit_t0 == "ja",1,0) +
    ifelse(is.na(x$lei_lebererk_t0) == FALSE & x$lei_lebererk_t0 == "ja",1,0) +        
    ifelse(is.na(x$dmohne_endorgan_t0) == FALSE & x$dmohne_endorgan_t0 == "ja",1,0) +        
    ifelse(is.na(x$halbseitenl_t0) == FALSE & x$halbseitenl_t0 == "ja",2,0) +          
    ifelse(is.na(x$msch_sch_nierenerk_t0) == FALSE & x$msch_sch_nierenerk_t0 == "ja",2,0) +            
    ifelse(is.na(x$dm_endorgansch_t0) == FALSE & x$dm_endorgansch_t0 == "ja",2,0) +
    ifelse(is.na(x$tumorerkr_t0 ) == FALSE & x$tumorerkr_t0 == "ja",2,0) +
    ifelse(is.na(x$leukaemie_t0) == FALSE & x$leukaemie_t0 == "ja",2,0) +        
    ifelse(is.na(x$lymphom_t0) == FALSE & x$lymphom_t0 == "ja",2,0) +  
    ifelse(is.na(x$msch_sch_lebererk_t0) == FALSE & x$msch_sch_lebererk_t0 == "ja",3,0) +
    ifelse(is.na(x$metast_sol_tumor_t0) == FALSE & x$metast_sol_tumor_t0 == "ja",6,0) +      
    ifelse(is.na(x$hiv_aids_t0) == FALSE & x$hiv_aids_t0 == "ja",6,0)  
}

calculate_CCI(x)


## ---------------------------------------------------------------------------------------------------------------------
CCI <- function(i){
  calculate_CCI(bloomyDataExtrakt[i,])
}
CCI(1)

bloomyDataExtrakt$CCI <- sapply(1:dim(bloomyDataExtrakt)[1], CCI)
bloomyDataExtrakt$CCI <- bloomyDataExtrakt$CCI + bloomyDataExtrakt$CCI_age_score

write.table(x = "\nDistribution of CCI:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(bloomyDataExtrakt$CCI, useNA = "always"),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

# in-line analysis
# ----------------
g_0 <- filter(bloomyDataExtrakt,entl_ort_ent == "Im Krankenhaus verstorben")$CCI
g_1 <- filter(bloomyDataExtrakt,entl_ort_ent != "Im Krankenhaus verstorben")$CCI

pdf(file = paste(output_inline_analysis,"Bloomy_CCI_versus_Status.pdf",sep = ""))
boxplot(g_0,
        g_1, 
        main = "BLOOMY: CCI for died versus survived",
        names = c("died","surived"),
        ylab = "CCI")
dev.off()

# data frame

df <- data.frame(
  groups = c(rep("died",length(as.vector(table(g_0)))),
             rep("surv",length(as.vector(table(g_1))))),
  score = c(1:length(as.vector(table(g_0))),1:length(as.vector(table(g_1)))),
  values = c(as.vector(table(g_0)), as.vector(table(g_1))))
df <- tidyr::spread(df, groups, values)

if(length(is.na(df$surv)) >0){
  df$surv[which(is.na(df$surv))] <- 0
}
if(length(is.na(df$died)) >0){
  df$died[which(is.na(df$died))] <- 0
}

write.table(x = "\nDistribution of CCI by discharge status:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = df,
            file = ILA_file,
            col.names = TRUE, row.names = FALSE, append = TRUE, quote = FALSE)

# chi-square
M <- as.table(rbind(df$died, df$surv))
dimnames(M) <- list(group = c("died","survived"), score = 1:dim(M)[2])

cqt <- chisq.test(M)

write.table(x = "\nchi-square test for null hypthesis of 'no diference':",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
write.table(x = "\n   p-value:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
write.table(x = round(cqt$p.val,4),
            file = ILA_file,
            col.names = TRUE, row.names = FALSE, append = TRUE, quote = FALSE)
write.table(x = "\n   degrees of freedom:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
write.table(x = cqt$parameter,
            file = ILA_file,
            col.names = TRUE, row.names = FALSE, append = TRUE, quote = FALSE)

## ---------------------------------------------------------------------------------------------------------------------
write.csv(bloomyDataExtrakt,
           paste(output_data_folder,"BloomyData_Step02.csv",sep = ""),
          row.names = FALSE)

## ---------------------------------------------------------------------------------------------------------------------
Bloomy_StaphAur <- filter(bloomyDataExtrakt, err1_gram_pos_mb == "Staphylococcus aureus" |err2_gram_pos_mb == "Staphylococcus aureus")

## ---------------------------------------------------------------------------------------------------------------------
write.csv(Bloomy_StaphAur,
           paste(output_data_folder,"SA_BloomyData_Step03.csv",sep = ""),
          row.names = FALSE)

