
#####################################################################
#   BP01_S02:                                                       #
#                                                                   #
#   This code implements the first step of gene data preparation.   #
#   It is specifically designed to get the UniRef100-Data           # 
#   (coding or non-coding)!                                         #
#####################################################################

library(dplyr)

#=======================#
#   1. Fix file paths   #
#=======================#

source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/B_01_PreparationOfGeneData_SpecificSteps/B.01_ModelUniRef100_01/01_Data/10_ControlFiles/ControlFile.R")

#==============================#
#   2. Clear out-file folders  #
#==============================#
remove_old_files <- function(oldFilesFolder){
  tmp <- list.files(oldFilesFolder)
  if(length(tmp) > 0){
    file.remove(paste(oldFilesFolder,list.files(oldFilesFolder), sep = "/"))
  }  
}

remove_old_files(report_and_analysis_folder)
remove_old_files(out_data_folder)
remove_old_files(in_line_analysis_folder)

#=======================================================#
#   3. Prepare the file for the in-line-analysis        #
#=======================================================#
# Here we delete any existing file in the first step and 
# create an empty one in the second.

ILA_file <- paste(in_line_analysis_folder,"ILA_Gene_DataTransformation_UniRef100.txt",sep = "")
if(file.exists(ILA_file)){
  file.remove(ILA_file)  
}else{
  file.create(ILA_file)
}

#=======================#
#   4. Read data        #
#=======================#

inData <- 
  read.delim(paste(in_data_folder, "2025-09-08_combined_bakta_all643Samples_ver1.tsv", sep = ""),
             header=FALSE)

write.table(x = "\nDimension of input data frame:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(inData),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#==========================================#
#   5. Correct some inconsistencies        #
#==========================================#
tmp <- which(inData$V10 == "")
unique(inData[tmp,]$V9)

if(length(tmp) > 0){
  wrongones <- inData[tmp,]
  tpp <- grep("RefSeq:",wrongones$V9)
  print(length(tpp))
  if(length(tpp) > 0){
  inData$V10[tpp] <- inData$V9[tpp]
  }
}

write.table(x = "\nNumber of inconsitencies corrected in very fist step:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = length(tpp),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)


#==========================================#
#   6. Extract UniRef100 information        #
#==========================================#
inData <- inData[,-c(2,3,4,5,6,7,9)]

colnames(inData) <- c("case","gene","mixedField")

field <- inData$mixedField[34]

make_UniRef100 <- function(field){
  tmp <- unlist(strsplit(field,", "))
  ind <- grep("UniRef100_",tmp)
  if(length(ind) > 0){
    out <- as.vector(tmp[ind],mode = "character")
  }else{
    out <- NA
  }
  return(out)  
}

inData$UniRef_100 <- NA

for(i in 1:length(inData$mixedField)){
  inData$UniRef_100[i] <- make_UniRef100(inData$mixedField[i])
  if(i %% 10000 == 0){
    print(i)
  }
}
head(inData$UniRef_100)

write.table(x = "\nData sets after Uni-Ref selection::",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(inData),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(inData,
            paste(out_data_folder,"raw_castedData_LongFormat.csv",sep =""),
            sep = ";",
            quote = TRUE)

#==========================================#
#   7. Cleaning                            #
#==========================================#

nana <- which(is.na(inData$UniRef_100))
length(nana)
inData <- inData[-nana,]

# 
inData <- filter(inData, is.na(UniRef_100) == FALSE)
inData <- filter(inData, nchar(inData$UniRef_100) > 0)

#unique(inData$gene)

write.table(x = "\nData sets after cleaning:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(inData),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(inData,
            paste(out_data_folder,"castedData_LongFormat.csv",sep =""),
            sep = ";",
            quote = TRUE)

#==========================================#
#   8. Change format of data frame         #
#==========================================#

castedData <- reshape2::acast(inData[,c(1,4)], case ~ UniRef_100)


write.table(x = "\nData sets after re-formating data frame (long to wide):",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(castedData),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(castedData,
            paste(out_data_folder,"castedData.csv",sep =""),
            sep = ";",
            quote = TRUE)
