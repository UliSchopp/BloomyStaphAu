#######################################################################
#   This code serves as the central control file                      #
#   comprising the model's name and paths to all in- and output files #
#   concerned with analysis of one gene together with all selected    #
#   clinical parameter.                                               #
#                                                                     #
#   BP01_S01                                                          #
#######################################################################

# Theses folders contain data from former processing steps
path_II <- 
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_01_PreparationOfClinicalData/"
additional_data_folder <- 
  paste(path_II,"01_Data/50_ProcessedData/", sep = "")
in_data_folder  <- 
  "S:/250905_Bioinformatics_Reanalysis/"

# Theses folders refer to folders, that should hold new results
path_I <- 
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/B_01_PreparationOfGeneData_SpecificSteps/"
out_data_folder <- 
  paste(path_I,"B.01_ModelUniref90_01/01_Data/50_ProcessedData/",sep="")
in_line_analysis_folder <- 
  paste(path_I,"B.01_ModelUniref90_01/01_Data/20_InLineAnalysis/",sep="")
report_and_analysis_folder <- 
  paste(path_I,"B.01_ModelUniref90_01/01_Data/70_AnalysisAndOverview/",sep="")
elementsDistanceAnalysis <- 
  paste(report_and_analysis_folder,"/ElementsDistances/",sep="")
strainsDistanceAnalysis <- 
  paste(report_and_analysis_folder,"/StrainsDistances/",sep="")

dir.create(out_data_folder, showWarnings = FALSE)
dir.create(in_line_analysis_folder, showWarnings = FALSE)
dir.create(report_and_analysis_folder, showWarnings = FALSE)
dir.create(elementsDistanceAnalysis, showWarnings = FALSE)
dir.create(strainsDistanceAnalysis, showWarnings = FALSE)