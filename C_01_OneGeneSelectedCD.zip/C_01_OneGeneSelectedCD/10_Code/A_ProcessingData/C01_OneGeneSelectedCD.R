#####################################################################
#   C01:                                                            #
#                                                                   #
#   This code implements:                                           #
#   1. Joining the genetic data with clinical parameter             #
#      In former versions this was also called "merging".           #
#      The trouble was, that in another step data from              #
#      two distinct studies were merged, so that naming             #
#      the files was messy: In the old versions all data files      #
#      were merged at the end.                                      #
#      We decided that putting together data from different studies #
#      is called "merging" and adding clinical parameters to genetic#
#      data is named "joining"                                      #
#                                                                   #
#   ATTENTION: Reading the data is controlled by one central        #
#              file!                                                #
#####################################################################

library(dplyr)
library(writexl)
library(car)
library(Hmisc)

#=======================#
#   1. Fix file paths   #
#=======================#

source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/C_01_OneGeneSelectedCD/01_Data/10_ControlFiles/ControlFile.R")

#==============================#
#   2. Clear out-file folders  #
#==============================#
remove_old_files <- function(oldFilesFolder){
  tmp <- list.files(oldFilesFolder)
  if(length(tmp) > 0){
    file.remove(paste(oldFilesFolder,list.files(oldFilesFolder), sep = "/"))
  }  
}

remove_old_files(report_and_analysis_folder)
remove_old_files(out_data_folder)
remove_old_files(in_line_analysis_folder)

#=======================================================#
#   3. Prepare the file for the in-line-analysis        #
#=======================================================#

ILA_file <- paste(in_line_analysis_folder,"ILA_OneGeneSelectedCD.txt",sep = "")
if(file.exists(ILA_file)){
  file.remove(ILA_file)  
}else{
  file.create(ILA_file)
}

#========================#
#   4. Read data         #
#========================#

StaphDaten <- 
  read.csv(paste(path_I, "SA_Data_Step06.csv", sep = ""))

StaphDaten <- data.frame(StaphDaten)

write.table(x = "\nNumber of data sets (validation and training):",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(StaphDaten$TrainingData),
            file = ILA_file,
            col.names = TRUE, row.names = FALSE, append = TRUE, quote = FALSE)

#======================================================#
#   5. Split into validation and training data         #
#======================================================#
ValDaten   <- filter(StaphDaten, TrainingData == 0)
TraDaten   <- filter(StaphDaten, TrainingData == 1)

#=============================#
#   6. Read gene data         #
#=============================#

caseDataTraining <-
  data.frame(read.table(paste(path_II ,"mergedDataTraining.txt",sep =""), sep = ";", header = TRUE))

write.table(x = "\nNumber of data sets for training:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(caseDataTraining)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = "\nNumber of features in training data:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(caseDataTraining)[2],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

caseDataValidation <- 
  data.frame(read.table(paste(path_II ,"mergedDataValidation.txt",sep =""), sep = ";", header = TRUE))

write.table(x = "\nNumber of data sets for validation:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(caseDataValidation)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = "\nNumber of features in validation data:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(caseDataValidation)[2],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#========================================================#
#   7. Read pre-selected clinical parameter names        #
#========================================================#
featInModel <- 
  as.vector(read.table(paste(path_III,"Preliminary_ClinicalFeatureSet.csv",sep =""),
                       sep = "\t", header = FALSE))$V1

featInModel <- c("entl_ort_ent", "Extended_studiso_id_Short", featInModel)

#==================================================#
#   8. Read pre-selected gene names                #
#==================================================#
GenesInModel <- 
  as.vector(read.table(paste(path_II,"GenesAfterPropTestSievingAndRelAmountSelection.txt",sep =""),
                       sep = "\t", header = TRUE))$geneName

write.table(x = "\nNumber of genes:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = length(GenesInModel),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

##############################################################
#                                                            #
#              Process the training data                     #
#              #########################                     #
#                                                            #
##############################################################

#===========================================================#
#   9. Select the clinical data (here: training data)       #
#===========================================================#
selTraDaten <- TraDaten[,featInModel]

write.table(x = "\nNumber of clinical parameter to be joined to training data:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(selTraDaten)[2],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)


write.table(x = "\nNumber of training data before cleaning for incomplete data sets:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(selTraDaten)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#==================================================#
#   10. Delete Incomplete Data Sets                 #
#==================================================#
for(i in 2:dim(selTraDaten)[2]){
  tmp <- which(is.na(selTraDaten[,i]))
  print(length(tmp))
  if(length(tmp) > 0){
    selTraDaten <- selTraDaten[-tmp,]
  }
}

write.table(x = "\nNumber of training data after cleaning for incomplete data sets:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(selTraDaten)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#==================================================#
#   11. Re-code the outcome                        #
#==================================================#
selTraDaten$entl_ort_ent <- 
  factor(ifelse(selTraDaten$entl_ort_ent == "Im Krankenhaus verstorben",1,0))

write.table(x = "\nNumber of survived (= 0) and died (= 1) patients in training data:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(selTraDaten$entl_ort_ent),
            file = ILA_file,
            col.names = TRUE, row.names = FALSE, append = TRUE, quote = FALSE)

#==================================================#
#   12. Select genetic features                    #
#==================================================#
caseDataTraining <- 
  caseDataTraining[,which(colnames(caseDataTraining) %in% c("FALL",GenesInModel))]

write.table(x = "\nNumber of training data sets:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(caseDataTraining)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = "\nNumber of features in training data sets after selection:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(caseDataTraining)[2],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#==================================================#
#   13. Join with clinical data                    #
#==================================================#

#   13.1 Create and add a new key which is common
#        to both data sets to be joined.

extend_StudyIsoNumber <- function(x){
  xx <- unlist(strsplit(x, "-"))
  if(length(xx) == 4){
    if(nchar(xx[3]) == 3){
      nx <- paste(xx[1],"-",xx[2],"-0",xx[3],sep = "")
      return(nx)}else{
        nx <-  paste(xx[1],"-",xx[2],"-",xx[3],sep = "")
        return(nx)}
  }else{
    if(nchar(xx[3]) == 3){
      nx <- paste(xx[1],"-",xx[2],"-0",xx[3],sep = "")
      return(nx)}else{
        nx <- x
        return(nx)}
  }
}

# This inline code serves as a test
#extend_StudyIsoNumber(caseDataTraining$FALL[1])
#extend_StudyIsoNumber(caseDataTraining$FALL[204])

caseDataTraining$Extended_studiso_id_Short <-
  sapply(caseDataTraining$FALL, extend_StudyIsoNumber)

#   13.2 Now data sets can be joined

joined_Training <- 
  merge(x = selTraDaten,
        y = caseDataTraining,
        by.x = "Extended_studiso_id_Short",
        by.y = "Extended_studiso_id_Short")

write.table(joined_Training,
            paste(out_data_folder,"joined_training_data.txt",sep = ""))

write.table(x = "\nNumber of training data after merging:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(joined_Training)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = "\nNumber of data fields in the training data after merging:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(joined_Training)[2],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)


#############################################################
#                                                           #
#              Process the validation data                  #
#              ###########################                  #
#                                                           #
#############################################################

#===========================================================#
#   14. Select the clinical data (here: validation data)    #
#===========================================================#

selValDaten <- ValDaten[,featInModel]

write.table(x = "\nNumber of clinical parameter to be joined to validation data:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(selValDaten)[2],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)


write.table(x = "\nNumber of validation data before cleaning for incomplete data sets:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(selValDaten)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)


#==================================================#
#   15. Delete Incomplete Data Sets                #
#==================================================#

for(i in 2:dim(selValDaten)[2]){
  tmp <- which(is.na(selValDaten[,i]))
  if(length(tmp) > 0){
    selValDaten <- selValDaten[-tmp,]
  }
}

write.table(x = "\nNumber of validation data after cleaning for incomplete data sets:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(selValDaten)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#==================================================#
#   16. Re-code the outcome                        #
#==================================================#

selValDaten$entl_ort_ent <- factor(ifelse(selValDaten$entl_ort_ent == "Im Krankenhaus verstorben",1,0))

write.table(x = "\nNumber of survived (= 0) and died (= 1) patients in validation data:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = table(selTraDaten$entl_ort_ent),
            file = ILA_file,
            col.names = TRUE, row.names = FALSE, append = TRUE, quote = FALSE)

#==================================================#
#   17. Select genetic features                    #
#==================================================#

caseDataValidation <- caseDataValidation[,which(colnames(caseDataValidation) %in% c("FALL",GenesInModel))]

write.table(x = "\nNumber of validation data sets:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(caseDataTraining)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = "\nNumber of features in validation data sets after selection:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(caseDataTraining)[2],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)


#==================================================#
#   18. Join with clinical data                    #
#==================================================#

caseDataValidation$Extended_studiso_id_Short <-
  sapply(caseDataValidation$FALL, extend_StudyIsoNumber)

joined_Validation <- 
  merge(x = selValDaten,
        y = caseDataValidation,
        by.x = "Extended_studiso_id_Short",
        by.y = "Extended_studiso_id_Short")

write.table(joined_Validation,
            paste(out_data_folder,"joined_validation_data.txt",sep = ""))

write.table(x = "\nNumber of validatoin data after merging:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(joined_Validation)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = "\nNumber of data fields in the validation data after merging:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(joined_Validation)[2],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)


#############################################################
#                                                           #
#              ANOVA                                        #
#              #####                                        #
#                                                           #
#############################################################

gene_cols     <- which(colnames(joined_Training) %in% GenesInModel)
non_gene_cols <- which(colnames(joined_Training) %nin% GenesInModel)

result_data_frame <- data.frame(Gene = rep(NA,length(gene_cols)),
                                p_value = rep(NA,length(gene_cols)))
i <- 4
for(i in 1:length(gene_cols)){
  selTraGLM <- joined_Training[,c(non_gene_cols,gene_cols[i])][,-1]
  selTraGLM <- selTraGLM[,-which(colnames(selTraGLM) %in% c("FALL","Extended_studio_id_Short"))]
  
  glm_res <- glm(entl_ort_ent ~ ., data = selTraGLM, family = "binomial")
  (anres <- Anova(glm_res))
  out.tmp <- data.frame(anres[3])
  result_data_frame$Gene[i] = row.names(out.tmp)[dim(out.tmp)[1]]
  result_data_frame$p_value[i] = round(out.tmp[dim(out.tmp)[1],],4)
}

write_xlsx(result_data_frame,
           paste(out_data_folder,"ANOVA_OneGeneSelectedCD.xlsx",sep = ""))

write.csv(result_data_frame,
          paste(report_and_analysis_folder,"ANOVA_OneGeneSelectedCD.csv",sep = ""),
          row.names = FALSE)

write.table(x = "\nNumber of genes after ANOVA before application of p-value threshold:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(result_data_frame)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

# application of p-value threshold
reducedResultDataFrame <- filter(result_data_frame, p_value <= ANOVA_LL_pval.threshold)

write.table(x = "\nNumber of genes after ANOVA after application of p-value threshold:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(reducedResultDataFrame)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write_xlsx(reducedResultDataFrame,
           paste(report_and_analysis_folder,"Reduced_ANOVA_OneGeneSelectedCD.xlsx",sep = ""))

write.csv(reducedResultDataFrame,
           paste(out_data_folder,"Reduced_ANOVA_OneGeneSelectedCD.csv",sep = ""),
           row.names = FALSE)

