#######################################################################
#   This code serves as the central control file                      #
#   comprising the model's name and paths to all in- and output files #
#   concerned with analysis of one gene together with all selected    #
#   clinical parameter.                                               #
#######################################################################

modelName <- "ModelUniref90_01"

path_I <- 
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_01_PreparationOfClinicalData/01_Data/50_ProcessedData/"

path_II <- 
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/B_02_PreparationOfGeneData_CommonSteps/01_Data/"
path_II <- paste(path_II,modelName,"/50_ProcessedData/",sep = "")

path_III <- 
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_02_ClinicalData_FeatureSelection/01_Data/50_ProcessedData/"

path_IV <-
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/C_01_OneGeneSelectedCD/01_Data/"
out_data_folder <- 
  paste(path_IV,modelName,"/50_ProcessedData/",sep="")
in_line_analysis_folder <- 
  paste(path_IV,modelName,"/20_InLineAnalysis/",sep="")
report_and_analysis_folder <- 
  paste(path_IV,modelName,"/70_AnalysisAndOverview/",sep="")
dir.create(paste(path_IV,modelName,sep = ""), showWarnings = FALSE)
dir.create(out_data_folder, showWarnings = FALSE)
dir.create(in_line_analysis_folder, showWarnings = FALSE)
dir.create(report_and_analysis_folder, showWarnings = FALSE)

# Threshold for ANOVA likelihood test in models with one gene and selected clinical data
ANOVA_LL_pval.threshold <- 0.05
