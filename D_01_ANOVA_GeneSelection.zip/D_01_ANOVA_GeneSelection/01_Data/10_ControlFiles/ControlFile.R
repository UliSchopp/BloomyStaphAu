#######################################################################
#   This code serves as the central control file                      #
#   comprising the model's name and paths to all in- and output files #
#   concerned with analysis of one gene together with all selected    #
#   clinical parameter.                                               #
#                                                                     #
#   D_01                                                              #
#######################################################################

modelName <- "ModelUniref100_01"
modelNameForPlot <- "Model A"

path_I <- 
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_01_PreparationOfClinicalData/01_Data/50_ProcessedData/"

path_II <- 
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/B_02_PreparationOfGeneData_CommonSteps/01_Data/"
path_II <- paste(path_II,modelName,"/50_ProcessedData/",sep = "")

path_III <- 
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_02_ClinicalData_FeatureSelection/01_Data/50_ProcessedData/"

path_IV <-
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/C_01_OneGeneSelectedCD/01_Data/"
path_IV <- 
  paste(path_IV,modelName,"/50_ProcessedData/",sep="")

path_V <-
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/D_01_ANOVA_GeneSelection/01_Data/"

# ordinary analysis with elements and with CD
dir.create(paste(path_V,modelName,sep = ""), showWarnings = FALSE)
out_data_folder <- 
  paste(path_V,modelName,"/50_ProcessedData/",sep="")
in_line_analysis_folder <- 
  paste(path_V,modelName,"/20_InLineAnalysis/",sep="")
report_and_analysis_folder <- 
  paste(path_V,modelName,"/70_AnalysisAndOverview/",sep="")
ToScoary_folder <- 
  paste(path_V,modelName,"/80_ScoryInputDataSets/",sep="")

dir.create(paste(path_IV,modelName,sep = ""), showWarnings = FALSE)
dir.create(out_data_folder, showWarnings = FALSE)
dir.create(in_line_analysis_folder, showWarnings = FALSE)
dir.create(report_and_analysis_folder, showWarnings = FALSE)
dir.create(ToScoary_folder, showWarnings = FALSE)

write_ANOVA_to_this <- 
  paste(out_data_folder, "AllGeneSelectionResults", sep = "")
dir.create(write_ANOVA_to_this, showWarnings = FALSE)

write_Details_about_ANOVA_to_this <- 
  paste(write_ANOVA_to_this, "/ANOVA_Details", sep = "")
dir.create(write_Details_about_ANOVA_to_this, showWarnings = FALSE)

write_ROC_Curves_to_this <- 
  paste(out_data_folder, "ROC_Curves", sep = "")
dir.create(write_ROC_Curves_to_this, showWarnings = FALSE)

write_ROC_movieFiles_to_this <-
  paste(out_data_folder, "ROC_movieFiles", sep = "")
dir.create(write_ROC_movieFiles_to_this, showWarnings = FALSE)

write_ROC_Curves_pdf_to_this <- 
  paste(out_data_folder, "ROC_Curves_PDF", sep = "")
dir.create(write_ROC_Curves_pdf_to_this, showWarnings = FALSE)

write_BoxWhiskerPlots_to_this <- 
  paste(out_data_folder, "BoxWhiskerPlots", sep = "")
dir.create(write_BoxWhiskerPlots_to_this, showWarnings = FALSE)

write_AUROCPlots_to_this <- 
  paste(out_data_folder, "AUROCPlots", sep = "")
dir.create(write_AUROCPlots_to_this, showWarnings = FALSE)

# for additional analysis 'without clinical data' as implemented in
# 'primed' version of the code: This is the middle type of "without CD"

write_ANOVA_Prime_to_this <- 
  paste(out_data_folder, "Prime_AllGeneSelectionResults", sep = "")
dir.create(write_ANOVA_Prime_to_this, showWarnings = FALSE)

write_Details_about_ANOVA_Prime_to_this <- 
  paste(write_ANOVA_Prime_to_this, "/Prime_ANOVA_Details", sep = "")
dir.create(write_Details_about_ANOVA_Prime_to_this, showWarnings = FALSE)

write_ROC_Curves_Prime_to_this <- 
  paste(out_data_folder, "Prime_ROC_Curves", sep = "")
dir.create(write_ROC_Curves_Prime_to_this, showWarnings = FALSE)

write_ROC_movieFiles_Prime_to_this <-
  paste(out_data_folder, "Prime_ROC_movieFiles", sep = "")
dir.create(write_ROC_movieFiles_Prime_to_this, showWarnings = FALSE)

write_ROC_Curves_Prime_pdf_to_this <- 
  paste(out_data_folder, "Prime_ROC_Curves_PDF", sep = "")
dir.create(write_ROC_Curves_Prime_pdf_to_this, showWarnings = FALSE)

write_BoxWhiskerPlots_Prime_to_this <- 
  paste(out_data_folder, "Prime_BoxWhiskerPlots", sep = "")
dir.create(write_BoxWhiskerPlots_Prime_to_this, showWarnings = FALSE)

write_AUROCPlots_Prime_to_this <- 
  paste(out_data_folder, "Prime_AUROCPlots", sep = "")
dir.create(write_AUROCPlots_Prime_to_this, showWarnings = FALSE)

# for additional analysis 'without clinical data' as implemented in
# 'double primed' version of the code: This is the weak type of "without CD"

write_ANOVA_DoublePrime_to_this <- 
  paste(out_data_folder, "DoublePrime_AllGeneSelectionResults", sep = "")
dir.create(write_ANOVA_DoublePrime_to_this, showWarnings = FALSE)

write_Details_about_ANOVA_DoublePrime_to_this <- 
  paste(write_ANOVA_Prime_to_this, "/DoublePrime_ANOVA_Details", sep = "")
dir.create(write_Details_about_ANOVA_DoublePrime_to_this, showWarnings = FALSE)

write_ROC_Curves_DoublePrime_to_this <- 
  paste(out_data_folder, "DoublePrime_ROC_Curves", sep = "")
dir.create(write_ROC_Curves_DoublePrime_to_this, showWarnings = FALSE)

write_ROC_movieFiles_DoublePrime_to_this <-
  paste(out_data_folder, "DoublePrime_ROC_movieFiles", sep = "")
dir.create(write_ROC_movieFiles_DoublePrime_to_this, showWarnings = FALSE)

write_ROC_Curves_DoublePrime_pdf_to_this <- 
  paste(out_data_folder, "DoublePrime_ROC_Curves_PDF", sep = "")
dir.create(write_ROC_Curves_DoublePrime_pdf_to_this, showWarnings = FALSE)

write_BoxWhiskerPlots_DoublePrime_to_this <- 
  paste(out_data_folder, "DoublePrime_BoxWhiskerPlots", sep = "")
dir.create(write_BoxWhiskerPlots_DoublePrime_to_this, showWarnings = FALSE)

write_AUROCPlots_DoublePrime_to_this <- 
  paste(out_data_folder, "DoublePrime_AUROCPlots", sep = "")
dir.create(write_AUROCPlots_DoublePrime_to_this, showWarnings = FALSE)

# Additional Analysis
additionalAnalyis_data_folder <- 
  paste(path_V,modelName,"/90_AdditionalAnalysis/",sep="")
dir.create(additionalAnalyis_data_folder, showWarnings = FALSE)

# path to additional data
read_add_data_from_here <- 
  paste(path_V,"/20_AdditionalData/",modelName, sep = "")

# Threshold for ANOVA selection
mr.threshold <- 0#0.0005
dim.threshold <- 1#4

