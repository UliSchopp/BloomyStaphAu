input_data_path_B <- "P:\\DataAnalysis\\BloomyStatistics_Method_XXIII\\Data\\"

lf <- list.files(paste(input_data_path_B,"AllGeneSelectionResults",sep = ""))

tmp <- data.frame(Number = rep(NA, length(lf)),
                  Name = rep(NA, length(lf)))

for(k in 1:length(lf)){
  tmp[k,1] <- as.numeric(unlist(strsplit(unlist(strsplit(lf[k],"_"))[5],"[.]"))[1])
  tmp[k,2] <- lf[k]
}
tmp <- tmp[order(tmp$Number, decreasing = TRUE),]


dta <- read.csv(paste(input_data_path_B,"AllGeneSelectionResults\\",tmp[1,2],sep = ""))
dta <- dta[,c(1,4)]
options(scipen = 10)
dta$PVAL <- ifelse(dta$Pr..Chisq.> 1e-5,round(dta$Pr..Chisq.,5)," < 1e-5")
dta <- dta[,c(1,3)]

dta$X <- sapply(dta$X,function(x){gsub("UniRef[.]","",x)})

library(Hmisc)
library(xtable)
colnames(dta) <- c("Element","p-Wert")
print(xtable(dta, digits = 5),include.rownames = FALSE)

