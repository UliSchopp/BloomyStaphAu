#####################################################################
#   D_01_DistanceBetweenElements:                                   #
#                                                                   #
#   This code implements:                                           #
#   Calculation of l_1 distance of elements                         #
#                                                                   #
#   ATTENTION: Reading the data is controlled by one central        #
#              file!                                                #
#####################################################################

library(dplyr)
library(tidyr)
library(writexl)

#=======================#
#   1. Fix file paths   #
#=======================#

#source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/D_01_ANOVA_GeneSelection/01_Data/10_ControlFiles/ControlFile.R")
source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/D_01_ANOVA_GeneSelection/01_Data/10_ControlFiles/ControlFileWithoutCD.R")

#==========================================================#
#   2. Read gene data                                      #
#==========================================================#
caseDataTraining <-
  data.frame(read.table(paste(path_II ,"mergedDataTraining.txt",sep =""), sep = ";", header = TRUE))

#==========================================================#
#   3. Read selected genes' names                          #
#==========================================================#

anres <- 
  read.csv(paste(path_IV, "Reduced_ANOVA_OneGeneSelectedCD.csv", sep = ""))

GenesInModel <- anres$Gene

inData <- caseDataTraining[,which(colnames(caseDataTraining) %in% GenesInModel)]
dim(inData)

#=======================================#
#   4. distance between elements        #
#=======================================#
tinData <- t(inData)
dim(tinData)

tinData[1:10,1:10]
dst <- dist(tinData, method = "manhattan", diag = TRUE, upper = TRUE)
am <- as.matrix(dst)

clnms <- colnames(am)
rwnms <- rownames(am)

# 
dm.am <- dim(am)

# number of columns to process in one step

out.am <- 
  data.frame(
    var_1 = rep(NA,dm.am[1]^2),
    var_2 = rep(NA,dm.am[1]^2),
    distance = rep(NA,dm.am[1]^2))

dm.am[1]^2
dim(out.am)

k <- 1

for(i in 1:dm.am[1]){
  for(j in 1:dm.am[1]){
    if(i!=j){
      
      out.am$var_1[k] = clnms[i]
      out.am$var_2[k] = rwnms[j]
      
      out.am$distance[k] = am[i,j]
    }
    k <- k+1
  }
}

out.am <- out.am[-which(is.na(out.am$var_1)),]

# check
n <- dim(am)[1]
dim(out.am)[1] == n^2 - n


#=======================================#
#   5. which to delete                 #
#=======================================#  

candidatesToDelete <- out.am[which(out.am$distance == 0),]  
# It's too messy!
candidatesToDelete <- unique(c(candidatesToDelete$var_1,candidatesToDelete$var_2))

length(candidatesToDelete)
inData <- caseDataTraining[,which(colnames(caseDataTraining) %in% candidatesToDelete)]
dim(inData)

cleanThisOut <- NA
i  <- 2
for(i in 1:length(candidatesToDelete)){
  
  l2Dist <- function(j){sum(abs(inData[,i] -inData[,j]))}
  sapply(i:dim(inData)[2],l2Dist)
  tmp <- which(sapply(i:dim(inData)[2],l2Dist) == 0) +i -1
  tmp 
  candidatesToDelete
  candidatesToDelete[tmp]
  # don't delete if only one with distance 0 left!
  tmp <- tmp[-1]
  candidatesToDelete[tmp]
  
  cleanThisOut <- c(cleanThisOut,candidatesToDelete[tmp])
  cleanThisOut <- unique(cleanThisOut)    
  cleanThisOut  
  i <- i + 1
  i
}


cleanThisOut
candidatesToRemain <- candidatesToDelete[-which(candidatesToDelete %in% cleanThisOut[-1])]
candidatesToRemain
out.am[which(out.am$distance == 0),]

anres$Include <- 1
anres$Include[which(anres$Gene %in% cleanThisOut[-1])] <- 0

write.csv(anres, paste(path_IV, "Reduced_ANOVA_OneGeneSelectedCD.csv", sep = ""))


#=======================================#
#   6. check                            #
#=======================================#
GenesInModel <- anres$Gene[which(anres$Include == 1)]

inData <- caseDataTraining[,which(colnames(caseDataTraining) %in% GenesInModel)]
dim(inData)

tinData <- t(inData)
dim(tinData)

tinData[1:10,1:10]
dst <- dist(tinData, method = "manhattan", diag = TRUE, upper = TRUE)
am <- as.matrix(dst)

clnms <- colnames(am)
rwnms <- rownames(am)

# 
dm.am <- dim(am)

# number of columns to process in one step

out.am <- 
  data.frame(
    var_1 = rep(NA,dm.am[1]^2),
    var_2 = rep(NA,dm.am[1]^2),
    distance = rep(NA,dm.am[1]^2))

dm.am[1]^2
dim(out.am)

k <- 1

for(i in 1:dm.am[1]){
  for(j in 1:dm.am[1]){
    if(i!=j){
      
      out.am$var_1[k] = clnms[i]
      out.am$var_2[k] = rwnms[j]
      
      out.am$distance[k] = am[i,j]
    }
    k <- k+1
  }
}

out.am <- out.am[-which(is.na(out.am$var_1)),]

# check
n <- dim(am)[1]
dim(out.am)[1] == n^2 - n

which(out.am$distance == 0)
