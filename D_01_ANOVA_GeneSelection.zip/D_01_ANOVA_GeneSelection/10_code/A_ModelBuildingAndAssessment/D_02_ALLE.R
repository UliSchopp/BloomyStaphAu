#####################################################################
#   D_02:                                                           #
#                                                                   #
#   This code implements:                                           #
#   1. Selection of genes by ANOVA                                  #
#   2. Only genes are to be deleted                                 #
#                                                                   #
#   ATTENTION: Reading the data is controlled by one central        #
#              file!                                                #
#####################################################################

library(car)
library(dplyr)
library(Hmisc)
library(writexl)

#=======================#
#   1. Fix file paths   #
#=======================#

source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/D_01_ANOVA_GeneSelection/01_Data/10_ControlFiles/ControlFile.R")
#source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/D_01_ANOVA_GeneSelection/01_Data/10_ControlFiles/ControlFileWithoutCD.R")

#==============================#
#   2. Clear out-file folders  #
#==============================#
# This doesn't work properly. R seems to have problems 
# with that. It's not vital at all.

remove_old_files <- function(oldFilesFolder){
  tmp <- list.files(oldFilesFolder)
  if(length(tmp) > 0){
    file.remove(paste(oldFilesFolder,list.files(oldFilesFolder), sep = "/"), recursive = TRUE)
  }  
}

remove_old_files(report_and_analysis_folder)
remove_old_files(ToScoary_folder)
remove_old_files(in_line_analysis_folder)

#=======================================================#
#   3. Prepare the file for the in-line-analysis        #
#=======================================================#

ILA_file <- paste(in_line_analysis_folder,"ILA_ANOVA_GeneSelection.txt",sep = "")
if(file.exists(ILA_file)){
  file.remove(ILA_file)  
}else{
  file.create(ILA_file)
}

#========================#
#   4. Read data         #
#========================#

StaphDaten <- 
  read.csv(
    paste(path_I, "SA_Data_Step06.csv", sep = ""))

StaphDaten <- data.frame(StaphDaten)

#======================================================#
#   5. Split into validation and training data         #
#======================================================#

ValDaten   <- filter(StaphDaten, TrainingData == 0)
TraDaten   <- filter(StaphDaten, TrainingData == 1)

#==========================================================#
#   6. Read selected clinical parameter names data         #
#==========================================================#
featInModel <- 
  as.vector(read.table(paste(path_III,"Preliminary_ClinicalFeatureSet.csv",sep =""),
                       sep = "\t", header = FALSE))$V1

featInModel <- c("entl_ort_ent", "Extended_studiso_id_Short", featInModel)
# This few lines of code had to be added due to the demand of running 
# models free of any clinical data!
tmp <- which(is.na(featInModel))
if(length(tmp) > 0){
  featInModel <- featInModel[-tmp]
}

# Training data
selTraDaten <- TraDaten[,featInModel]
# Validation data
selValDaten <- ValDaten[,featInModel]

#==========================================================#
#   7. Read gene data                                      #
#==========================================================#
caseDataTraining <-
  data.frame(read.table(paste(path_II ,"mergedDataTraining.txt",sep =""), sep = ";", header = TRUE))

caseDataValidation <- 
  data.frame(read.table(paste(path_II ,"mergedDataValidation.txt",sep =""), sep = ";", header = TRUE))

#==========================================================#
#   8. Read selected genes' names                          #
#==========================================================#

anres <- 
  read.csv(paste(path_IV, "Reduced_ANOVA_OneGeneSelectedCD.csv", sep = ""))

GenesInModel <- anres$Gene[which(anres$Include == 1)]

#==========================================================#
#   9. Delete incomplete data sets                         #
#==========================================================#

write.table(x = "\nNumber of training data before cleaning for incomplete data sets:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(selTraDaten)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

for(i in 1:dim(selTraDaten)[2]){
  tmp <- which(is.na(selTraDaten[,i]))
  print(length(tmp))
  if(length(tmp) > 0){
    selTraDaten <- selTraDaten[-tmp,]
  }
}

write.table(x = "\nNumber of training data after cleaning for incomplete data sets:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(selTraDaten)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#==================================================#
#   10. Re-code the outcome                         #
#==================================================#

selTraDaten$entl_ort_ent <- factor(ifelse(selTraDaten$entl_ort_ent == "Im Krankenhaus verstorben",1,0))

caseDataTraining <- caseDataTraining[,which(colnames(caseDataTraining) %in% c("FALL",GenesInModel))]

#==================================================#
#   11. Join with clinical data                     #
#==================================================#

#   11.1 Create and add a new key which is common
#        to both data sets to be joined.
extend_StudyIsoNumber <- function(x){
  xx <- unlist(strsplit(x, "-"))
  if(length(xx) == 4){
    if(nchar(xx[3]) == 3){
      nx <- paste(xx[1],"-",xx[2],"-0",xx[3],sep = "")
      return(nx)}else{
        nx <-  paste(xx[1],"-",xx[2],"-",xx[3],sep = "")
        return(nx)}
  }else{
    if(nchar(xx[3]) == 3){
      nx <- paste(xx[1],"-",xx[2],"-0",xx[3],sep = "")
      return(nx)}else{
        nx <- x
        return(nx)}
  }
}

#extend_StudyIsoNumber(caseDataTraining$FALL[1])
#extend_StudyIsoNumber(caseDataTraining$FALL[204])

caseDataTraining$Extended_studiso_id_Short <-
  sapply(caseDataTraining$FALL, extend_StudyIsoNumber)

#   11.2 Now data sets can be joined

joined_Training <- 
  merge(x = selTraDaten,
        y = caseDataTraining,
        by.x = "Extended_studiso_id_Short",
        by.y = "Extended_studiso_id_Short")

#   11.3 write to scoary data files
out <- joined_Training[,c("Extended_studiso_id_Short", "entl_ort_ent")]
colnames(out) <- c("isolate","trait")

write.table(out,
            file = paste(ToScoary_folder,"traits_Training.csv",sep = ""),
            row.names = FALSE, quote = FALSE, sep = ",")

tmp <- joined_Training[,-c(2,3,4,5,6)]

out <- 
  data.frame(GEN =colnames(tmp)[-1],
             t(tmp[,-1]),
             check.names = FALSE)
colnames(out)[-1] <- tmp[,1]

write.table(out,
            file = paste(ToScoary_folder,"genes_Training.csv",sep = ""),
            row.names = FALSE, quote = FALSE, sep = ",")

#==================================================#
#   12. The same with validation data              #
#==================================================#

# clean-up

write.table(x = "\nNumber of validation data before cleaning for incomplete data sets:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(selValDaten)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

for(i in 1:dim(selValDaten)[2]){
  tmp <- which(is.na(selValDaten[,i]))
  if(length(tmp) > 0){
    selValDaten <- selValDaten[-tmp,]
  }
}

write.table(x = "\nNumber of validation data before cleaning for incomplete data sets:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(selValDaten)[1],
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

# re-code
selValDaten$entl_ort_ent <- factor(ifelse(selValDaten$entl_ort_ent == "Im Krankenhaus verstorben",1,0))

# select
caseDataValidation <- caseDataValidation[,which(colnames(caseDataValidation) %in% c("FALL",GenesInModel))]

# prepare for joining
caseDataValidation$Extended_studiso_id_Short <-
  sapply(caseDataValidation$FALL, extend_StudyIsoNumber)

# join
joined_Validation <- 
  merge(x = selValDaten,
        y = caseDataValidation,
        by.x = "Extended_studiso_id_Short",
        by.y = "Extended_studiso_id_Short")

#   11.3 write to scoary data files
out <- joined_Validation[,c("Extended_studiso_id_Short", "entl_ort_ent")]
colnames(out) <- c("isolate","trait")

write.table(out,
            file = paste(ToScoary_folder,"traits_Validation.csv",sep = ""),
            row.names = FALSE, quote = FALSE, sep = ",")

tmp <- joined_Validation[,-c(2,3,4,5,6)]

out <- 
  data.frame(GEN =colnames(tmp)[-1],
             t(tmp[,-1]),
             check.names = FALSE)
colnames(out)[-1] <- tmp[,1]

write.table(out,
            file = paste(ToScoary_folder,"genes_Validation.csv",sep = ""),
            row.names = FALSE, quote = FALSE, sep = ",")

#==================================================#
#   13. Identify the gene columns                  #
#       as in the next step they matter            #
#==================================================#

gene_cols     <- which(colnames(joined_Training) %in% GenesInModel)
non_gene_cols <- which(colnames(joined_Training) %nin% GenesInModel)

#==================================================#
#   14. Step through ANOVA                         #
#==================================================#

  selTraGLM <- joined_Training[,c(non_gene_cols,gene_cols)][,-1]
  selTraGLM <- selTraGLM[,-which(colnames(selTraGLM) %in% c("FALL","Extended_studio_id_Short"))]
  
  mr <- 1 # zur Initialisierung
  anres <- matrix(10,10,10) # zur Initialisierung
  rownames(anres) <- rep("UniRef",10)
  
  act_step = 1
  dim.before <- dim(selTraGLM)[2]-1

  write.table(paste("Neue Liste, ", act_step-1, ", Startanzahl: ",dim.before),
              paste(write_ANOVA_to_this, "/ANOVA_SELECTION_STEP_LIST.csv",sep = ""), 
              append = FALSE, row.names = FALSE, col.names = FALSE)
  
# while(mr > mr.threshold & dim(anres)[1] > dim.threshold & 
#        length(grep("UniRef",rownames(anres), ignore.case = TRUE)) > 0){
  while(mr > mr.threshold & dim(anres)[1] > dim.threshold){    
    dim.before <- dim(selTraGLM)[2]-1
    glm_res <- glm(entl_ort_ent ~ ., data = selTraGLM, family = "binomial")
  
    anres <- Anova(glm_res)
    write.csv(anres,
              paste(write_Details_about_ANOVA_to_this, 
                    "\\ResultsFromAllGeneSelection_FirstStep_",act_step,".csv", 
                    sep = ""))
    
    # Entfernung der Df-0-Vars hat Vorrang
    tmp <- which(anres$Df==0)
    tmp
    if(length(tmp) > 1){
      delete <- 
        which(colnames(selTraGLM) %in% row.names(anres)[tmp] &
                colnames(selTraGLM)  %in% GenesInModel)
     
      selTraGLM <- selTraGLM[,-delete]
    }else{# Entfernen des 'schlechtesten' Gens!
    red.anres <- anres#[which(rownames(anres) %in% GenesInModel),]
    (mr <- max(red.anres$`Pr(>Chisq)`))
    (tmp <- which(red.anres$`Pr(>Chisq)` == mr)[1])
    print(row.names(red.anres)[tmp])
      tmp <- which(colnames(selTraGLM) == row.names(red.anres)[tmp])
    selTraGLM <- selTraGLM[,-tmp]
    dim.after <- dim(selTraGLM)[2]-1
    row.names(red.anres)[tmp]
    write.table(paste(row.names(red.anres)[tmp-1],#? 
                      act_step, dim.before, dim.after),
                paste(write_ANOVA_to_this,
                      "/ANOVA_SELECTION_STEP_LIST.csv", 
                      sep = ""), append = TRUE, row.names = FALSE, col.names = FALSE)
    }
    act_step = act_step +1
  }
  write.csv(anres,
              paste(write_ANOVA_to_this,
                    "/ResultsFromAllGeneSelection.csv", 
                    sep = ""))
              
  
