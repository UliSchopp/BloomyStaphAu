#####################################################################
#   D_03:                                                           #
#                                                                   #
#   This code implements:                                           #
#   1. Creates the ROC curves                                       #
#                                                                   #
#   ATTENTION: Reading the data is controlled by one central        #
#              file!                                                #
#                                                                   #
#   CAVE: ALL CASES are caculated in the FIRST part only            #
#   Make shure that last entry in ANOVA_SELECTION_STEP_LIST.csv     #
#   has four values (add a 0 if necessary)                          #
#####################################################################

library(car)
library(dplyr)
library(readxl)
library(writexl)


#=======================#
#   1. Fix file paths   #
#=======================#

source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/D_01_ANOVA_GeneSelection/01_Data/10_ControlFiles/ControlFile.R")
#source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/D_01_ANOVA_GeneSelection/01_Data/10_ControlFiles/ControlFileWithoutCD.R")

#=======================================================#
#   2. Prepare the file for the in-line-analysis        #
#=======================================================#

ILA_file <- paste(in_line_analysis_folder,"ILA_ROCCurves.txt",sep = "")
if(file.exists(ILA_file)){
  file.remove(ILA_file)  
}else{
  file.create(ILA_file)
}

#========================#
#   3. Read data         #
#========================#

StaphDaten <- 
  read.csv(
    paste(path_I, "SA_Data_Step06.csv", sep = ""))

StaphDaten <- data.frame(StaphDaten)

#======================================================#
#   4. Split into validation and training data         #
#======================================================#

ValDaten   <- filter(StaphDaten, TrainingData == 0)
TraDaten   <- filter(StaphDaten, TrainingData == 1)

#==========================================================#
#   7. Read gene data                                      #
#==========================================================#
caseDataTraining <-
  data.frame(read.table(paste(path_II, "mergedDataTraining.txt",sep =""), sep = ";", header = TRUE))

caseDataValidation <- 
  data.frame(read.table(paste(path_II, "mergedDataValidation.txt",sep =""), sep = ";", header = TRUE))

#==========================================================#
#   8. Prepare for ROC calculation                         #
#==========================================================#

ct <- caseDataTraining
cv <- caseDataValidation

caseList <- list.files(paste(write_Details_about_ANOVA_to_this,sep = ""))
x <- caseList[1]
helper   <- function(x){
  y <- unlist(strsplit(x,"_"))[3]
  z <- as.numeric(unlist(strsplit(y,"[.]"))[1])
  return(z)
}

od <- order(sapply(caseList,helper))
caseList <- caseList[od]
NN       <- length(caseList)

#==========================================================#
#                                                          #
#    A. This is for the ordinary analysis                  #
#    ####################################                  #
#                                                          #
#==========================================================#
out <- data.frame(
  case = rep(NA,NN),
  name = rep(NA,NN),
  number = rep(NA,NN),
  AUROC_T = rep(NA,NN),
  AUROC_T_L = rep(NA,NN),
  AUROC_T_H = rep(NA,NN),
  AUROC_V = rep(NA,NN),
  AUROC_V_L = rep(NA,NN),
  AUROC_V_H = rep(NA,NN),
  number_inv_T = rep(NA,NN),
  W_stat_T = rep(NA,NN),
  W_p_T = rep(NA,NN),
  number_inv_V = rep(NA,NN),
  W_stat_V = rep(NA,NN),
  W_p_V = rep(NA,NN),
  Training_Rank_Sums_0 =rep(NA,NN),
  Training_Rank_Sums_1 =rep(NA,NN),
  Validation_Rank_Sums_0 =rep(NA,NN),
  Validation_Rank_Sums_1 =rep(NA,NN),
  NormedTraining_Rank_Sums_1 =rep(NA,NN),
  NormedValidation_Rank_Sums_1=rep(NA,NN)
)

fileCounter <- 36
for(fileCounter in 1:NN){
  #for(fileCounter in 43:NN){  
  ValDaten   <- filter(StaphDaten, TrainingData == 0)
  TraDaten   <- filter(StaphDaten, TrainingData == 1)
  
  caseDataTraining <- ct
  caseDataValidation <- cv
  
  out$case[fileCounter] =  fileCounter
  out$name[fileCounter] = caseList[fileCounter]
  # read the interesting elements (genes and clinical)
  print(caseList[fileCounter])
  
  featInModel <- 
    as.vector(read.csv(paste(write_Details_about_ANOVA_to_this,
                             caseList[fileCounter], 
                             sep = "/")))$X
  
  # It may happen, that only clinical data are left in the model.
  # Then the calculation is useless!
  
  numberOfUniRef <- length(grep("Uni",featInModel))
  
  #if(numberOfUniRef > 0){
  
  out$number[fileCounter] <- length(featInModel)
  
  # isolate the clinical features
  # =============================
  clinicalFeaturesInModel <- featInModel[which(substr(featInModel,1,7) != "UniRef.")]
  selTraDaten <- TraDaten[,c("entl_ort_ent","Extended_studiso_id_Short",clinicalFeaturesInModel)]
  
  ##  Delete Incomplete Data Sets.
  
  for(i in 1:dim(selTraDaten)[2]){
    tmp <- which(is.na(selTraDaten[,i]))
    #print(length(tmp))
    if(length(tmp) > 0){
      selTraDaten <- selTraDaten[-tmp,]
    }
  }
  
  selTraDaten$entl_ort_ent <- factor(ifelse(selTraDaten$entl_ort_ent == "Im Krankenhaus verstorben",1,0))
  
  # isolate the UniRef features
  # ===========================
  nonClinicalFeaturesInModel <- featInModel[which(substr(featInModel,1,7) == "UniRef.")]
  
  if(length(nonClinicalFeaturesInModel) > 0){
    caseDataTraining <- 
      caseDataTraining[,which(colnames(caseDataTraining) %in% c("FALL",nonClinicalFeaturesInModel))]
  }else{
    caseDataTraining <- 
      caseDataTraining[,which(colnames(caseDataTraining) %in% c("FALL"))]
  }
  
  # create extended study number (again)
  # ====================================
  extend_StudyIsoNumber <- function(x){
    xx <- unlist(strsplit(x, "-"))
    if(length(xx) == 4){
      if(nchar(xx[3]) == 3){
        nx <- paste(xx[1],"-",xx[2],"-0",xx[3],sep = "")
        return(nx)}else{
          nx <-  paste(xx[1],"-",xx[2],"-",xx[3],sep = "")
          return(nx)}
    }else{
      if(nchar(xx[3]) == 3){
        nx <- paste(xx[1],"-",xx[2],"-0",xx[3],sep = "")
        return(nx)}else{
          nx <- x
          return(nx)}
    }
  }
  
  if(length(nonClinicalFeaturesInModel) > 0){
    caseDataTraining$Extended_studiso_id_Short <-
      sapply(caseDataTraining$FALL, extend_StudyIsoNumber)}else{
        caseDataTraining_tmp <- caseDataTraining
        caseDataTraining <- 
          data.frame(Extended_studiso_id_Short = caseDataTraining_tmp,
                     FALL = caseDataTraining_tmp)
        caseDataTraining$Extended_studiso_id_Short <- 
          sapply(caseDataTraining$FALL, extend_StudyIsoNumber)
      }
  
  joined_Training <- 
    merge(x = selTraDaten,
          y = caseDataTraining,
          by.x = "Extended_studiso_id_Short",
          by.y = "Extended_studiso_id_Short")
  
  head(joined_Training)
  ################################################################################
  # Validierungsdaten
  selValDaten <- ValDaten[,c("entl_ort_ent","Extended_studiso_id_Short",clinicalFeaturesInModel)]
  
  # ... Validierungssdaten
  for(i in 1:dim(selValDaten)[2]){
    tmp <- which(is.na(selValDaten[,i]))
    if(length(tmp) > 0){
      selValDaten <- selValDaten[-tmp,]
    }
  }
  
  selValDaten$entl_ort_ent <- factor(ifelse(selValDaten$entl_ort_ent == "Im Krankenhaus verstorben",1,0))
  
  
  if(length(nonClinicalFeaturesInModel) > 0){
    caseDataValidation <- 
      caseDataValidation[,which(colnames(caseDataValidation) %in% c("FALL",nonClinicalFeaturesInModel))]
  }else{
    caseDataValidation <- 
      caseDataValidation[,which(colnames(caseDataValidation) %in% c("FALL"))]
  }
  
  if(length(nonClinicalFeaturesInModel) > 0){
    caseDataValidation$Extended_studiso_id_Short <-
      sapply(caseDataValidation$FALL, extend_StudyIsoNumber)}else{
        caseDataValidation_tmp <- caseDataValidation
        caseDataValidation <- 
          data.frame(Extended_studiso_id_Short = caseDataValidation_tmp,
                     FALL = caseDataValidation_tmp)
        caseDataValidation$Extended_studiso_id_Short <- 
          sapply(caseDataValidation$FALL, extend_StudyIsoNumber)
      }
  
  joined_Validation <- 
    merge(x = selValDaten,
          y = caseDataValidation,
          by.x = "Extended_studiso_id_Short",
          by.y = "Extended_studiso_id_Short")
  
  head(joined_Validation)
  
  indices <- which(colnames(joined_Training) %in% c("entl_ort_ent",featInModel))
  
  selTraDaten <- joined_Training[,indices]
  selValDaten <- joined_Validation[,indices]
  
  library(car)
  glm_res <- glm(entl_ort_ent ~ ., data = selTraDaten, family = "binomial")
  #Anova(glm_res)
  
  glm_predicts <- 
    predict(glm_res, type = "response")
  ## Vorhersage für Trainingsdaten 
  df_TraPredictions  <-  
    data.frame(outcome = as.numeric(selTraDaten$entl_ort_ent)-1, 
               pred = fitted(glm_res))
  
  ## Vorhersage für Validierungsdaten 
  glm_ValPredictions  <-  
    predict(glm_res, 
            type = "response", 
            newdata = selValDaten)
  df_ValPredictions  <-  data.frame(outcome = as.numeric(as.vector(selValDaten$entl_ort_ent)), 
                                    pred = glm_ValPredictions)
  
  val.error <- FALSE
  if(dim(table(df_ValPredictions$outcome)) == 1){val.error <- TRUE}
  
  library(plotROC)
  library(PRROC)
  library(OptimalCutpoints)
  
  # Beste Parameter für Training
  optimal.cutpoint.Youden.Tra <- 
    optimal.cutpoints(X = "pred", 
                      status = "outcome", 
                      tag.healthy = 0,
                      methods = "Youden", 
                      data = df_TraPredictions, 
                      pop.prev = NULL, 
                      control = control.cutpoints(), 
                      ci.fit = TRUE, conf.level = 0.95, trace = FALSE)
  optimal.cutpoint.Youden.Tra
  out[fileCounter,4:6] <- optimal.cutpoint.Youden.Tra$Youden$Global$measures.acc$AUC
  
  df_TraPredictions$outcome <- as.numeric(df_TraPredictions$outcome)
  
  if(val.error == FALSE){
    # Beste Parameter für Validierung
    optimal.cutpoint.Youden.Val <- 
      optimal.cutpoints(X = "pred", 
                        status = "outcome", 
                        tag.healthy = 0,
                        methods = "Youden", 
                        data = df_ValPredictions, 
                        pop.prev = NULL, 
                        control = control.cutpoints(), 
                        ci.fit = TRUE, conf.level = 0.95, trace = FALSE)
    optimal.cutpoint.Youden.Val
    out[fileCounter,7:9] <- optimal.cutpoint.Youden.Val$Youden$Global$measures.acc$AUC
  }else{
    out[fileCounter,5:7] <- c(NA,NA,NA)
  }
  
  
  df_predictions_training    <-  df_TraPredictions
  df_predictions_validation  <-  df_ValPredictions
  
  df_predictions_training$Type   <- "Training"
  df_predictions_validation$Type <- "Validation"
  df_predictions <- rbind(df_predictions_training,
                          df_predictions_validation)
  df_predictions <- data.frame(df_predictions)
  #head(df_predictions)
  
  # muss man nicht verstehen, aber sonst klappt es mit den Filmchen nicht!
  op <- par()
  par(op)
  
  ggplot(df_predictions, 
         aes(d = outcome, m = pred, color = Type)) + 
    geom_roc(n.cut = 0) +
    style_roc() + 
    geom_abline(slope = 1,
                intercept = 0, 
                color = "grey50") +
    ggtitle(paste("ROC Curves - ",length(featInModel),"Feature"))
  
  
  ggsave(paste(write_ROC_Curves_to_this,"\\",substr(caseList[fileCounter],1,nchar(caseList[fileCounter])-4),".jpeg",sep = ""))
  
  if(length(featInModel) < 10){
    ggsave(paste(write_ROC_movieFiles_to_this,"//00",length(featInModel),".jpeg",sep = ""))}else{
      if(length(featInModel) < 100){
        ggsave(paste(write_ROC_movieFiles_to_this,"//0",length(featInModel),".jpeg",sep = ""))}else{
          ggsave(paste(write_ROC_movieFiles_to_this,"//",length(featInModel),".jpeg",sep = ""))
        }
    }
  
  ggsave(paste(write_ROC_Curves_pdf_to_this,"\\",substr(caseList[fileCounter],1,nchar(caseList[fileCounter])-4),".pdf",sep = ""))
  print(fileCounter)
  
  # Box-Whisker-Plots
  if(length(featInModel) < 10){
    jpeg(paste(write_BoxWhiskerPlots_to_this,"\\A00",length(featInModel),".jpeg",sep = ""))}else{
      if(length(featInModel) < 100){
        jpeg(paste(write_BoxWhiskerPlots_to_this,"\\A0",length(featInModel),".jpeg",sep = ""))}else{
          jpeg(paste(write_BoxWhiskerPlots_to_this,"\\A",length(featInModel),".jpeg",sep = ""))
        }
    }
  
  glm_coef <- glm_res$coefficients
  
  predicted_check <-
    predict(glm_res, 
            type = "response", 
            newdata = selValDaten)
  
  # alle Trainings-Daten
  op <- par()
  
  par(mfrow = c(2,1), mar = c(2, 1, 1, 1) + 0.1)
  plot(glm_res$model[,1],glm_res$fitted.values, main = length(featInModel),
       ylab = "vorhergesagte Wahrscheinlichkeit", xlab = "Outcome")
  plot(factor(df_predictions_validation[,1]),df_predictions_validation[,2], main = length(featInModel),
       ylab = "vorhergesagte Wahrscheinlichkeit", xlab = "Outcome")
  dev.off()
  
  
  # Test-Statistiken
  KS_training_01 <- cbind(glm_res$model[,1],glm_res$fitted.values)
  KS_training_01 <- KS_training_01[order(KS_training_01[,2]),]
  out$number_inv_T[fileCounter] <- sum(diff(KS_training_01[,1]) == -1)
  wt <- wilcox.test(KS_training_01[,2] ~ KS_training_01[,1])
  out$W_stat_T[fileCounter] <- wt$statistic
  out$W_p_T[fileCounter] <- wt$p.value
  
  KS_val_01 <- cbind(factor(df_predictions_validation[,1]),
                     df_predictions_validation[,2])
  KS_val_01 <- KS_val_01[order(KS_val_01[,2]),]
  out$number_inv_V[fileCounter] <- sum(diff(KS_val_01[,1]) == -1)
  wt <- wilcox.test(KS_val_01[,2] ~ KS_val_01[,1])
  out$W_stat_V[fileCounter] <- wt$statistic
  out$W_p_V[fileCounter] <- wt$p.value
  
  ## Rang-Statistik
  KS_training_01 <- data.frame(KS_training_01)
  colnames(KS_training_01) <- c("outcome","value")
  KS_training_01$rank <- 1:dim(KS_training_01)[1]
  a_0 <- table(KS_training_01$outcome)[1]
  a_1 <- table(KS_training_01$outcome)[2]
  th_training   <- (a_0+a_1)*(a_0+a_1+1)/2 -a_0*(a_0+1)/2
  
  out$Training_Rank_Sums_0[fileCounter] <-  sum(filter(KS_training_01,outcome == 1)$rank)
  out$Training_Rank_Sums_1[fileCounter] <-  sum(filter(KS_training_01,outcome == 2)$rank)
  out$NormedTraining_Rank_Sums_1[fileCounter] <-  sum(filter(KS_training_01,outcome == 2)$rank)/th_training
  
  KS_val_01 <- data.frame(KS_val_01)
  colnames(KS_val_01) <- c("outcome","value")
  KS_val_01$rank <- 1:dim(KS_val_01)[1]
  
  a_0 <- table(KS_val_01$outcome)[1]
  a_1 <- table(KS_val_01$outcome)[2]
  th_val  <- (a_0+a_1)*(a_0+a_1+1)/2 -a_0*(a_0+1)/2
  
  out$Validation_Rank_Sums_0[fileCounter] <-  sum(filter(KS_val_01,outcome == 1)$rank)
  out$Validation_Rank_Sums_1[fileCounter] <-  sum(filter(KS_val_01,outcome == 2)$rank)
  out$NormedValidation_Rank_Sums_1[fileCounter] <-  sum(filter(KS_val_01,outcome == 2)$rank)/th_val
  par(op)
}

if(length(which(is.na(out$AUROC_T))) > 0){
  out <- out[-which(is.na(out$AUROC_T)),]
}
write.table(out,
            paste(in_line_analysis_folder,"\\AUROC_TABLE.csv",sep=""),
            row.names = FALSE)

write_xlsx(out,
           paste(report_and_analysis_folder,"\\AUROC_TABLE.xlsx",sep=""))


#===============================================================#
#                                                               #
#    B. This is for the weak analysis                           #
#    ################################                           #
#    same elements as in the ordinary analysis but without CD   #
#                                                               #
#===============================================================#
out <- data.frame(
  case = rep(NA,NN),
  name = rep(NA,NN),
  number = rep(NA,NN),
  AUROC_T = rep(NA,NN),
  AUROC_T_L = rep(NA,NN),
  AUROC_T_H = rep(NA,NN),
  AUROC_V = rep(NA,NN),
  AUROC_V_L = rep(NA,NN),
  AUROC_V_H = rep(NA,NN),
  number_inv_T = rep(NA,NN),
  W_stat_T = rep(NA,NN),
  W_p_T = rep(NA,NN),
  number_inv_V = rep(NA,NN),
  W_stat_V = rep(NA,NN),
  W_p_V = rep(NA,NN),
  Training_Rank_Sums_0 =rep(NA,NN),
  Training_Rank_Sums_1 =rep(NA,NN),
  Validation_Rank_Sums_0 =rep(NA,NN),
  Validation_Rank_Sums_1 =rep(NA,NN),
  NormedTraining_Rank_Sums_1 =rep(NA,NN),
  NormedValidation_Rank_Sums_1=rep(NA,NN)
)

fileCounter <- 1
for(fileCounter in 1:NN){
  #for(fileCounter in 43:NN){  
  ValDaten   <- filter(StaphDaten, TrainingData == 0)
  TraDaten   <- filter(StaphDaten, TrainingData == 1)
  
  caseDataTraining <- ct
  caseDataValidation <- cv
  
  out$case[fileCounter] =  fileCounter
  out$name[fileCounter] = caseList[fileCounter]
  # read the interesting elements (genes and clinical)
  print(caseList[fileCounter])
  
  featInModel <- 
    as.vector(read.csv(paste(write_Details_about_ANOVA_to_this,
                             caseList[fileCounter], 
                             sep = "/")))$X
  #
  featInModel <- featInModel[grep("Uni",featInModel)] # take only the uni refs
  
  # It may happen, that only clinical data are left in the model.
  # Then the calculation is useless!
  
  numberOfUniRef <- length(grep("Uni",featInModel))
  
  if(numberOfUniRef > 0){
    
    out$number[fileCounter] <- length(featInModel)
    
    # isolate the clinical features
    # =============================
    #clinicalFeaturesInModel <- featInModel[which(substr(featInModel,1,7) != "UniRef.")]
    selTraDaten <-TraDaten[,c("entl_ort_ent","Extended_studiso_id_Short")]
    
    ##  Delete Incomplete Data Sets.
    
    for(i in 1:dim(selTraDaten)[2]){
      tmp <- which(is.na(selTraDaten[,i]))
      #print(length(tmp))
      if(length(tmp) > 0){
        selTraDaten <- selTraDaten[-tmp,]
      }
    }
    
    selTraDaten$entl_ort_ent <- factor(ifelse(selTraDaten$entl_ort_ent == "Im Krankenhaus verstorben",1,0))
    
    # isolate the UniRef features
    # ===========================
    nonClinicalFeaturesInModel <- featInModel[which(substr(featInModel,1,7) == "UniRef.")]
    
    caseDataTraining <- 
      caseDataTraining[,which(colnames(caseDataTraining) %in% c("FALL",nonClinicalFeaturesInModel))]
    
    # create extended study number (again)
    # ====================================
    extend_StudyIsoNumber <- function(x){
      xx <- unlist(strsplit(x, "-"))
      if(length(xx) == 4){
        if(nchar(xx[3]) == 3){
          nx <- paste(xx[1],"-",xx[2],"-0",xx[3],sep = "")
          return(nx)}else{
            nx <-  paste(xx[1],"-",xx[2],"-",xx[3],sep = "")
            return(nx)}
      }else{
        if(nchar(xx[3]) == 3){
          nx <- paste(xx[1],"-",xx[2],"-0",xx[3],sep = "")
          return(nx)}else{
            nx <- x
            return(nx)}
      }
    }
    
    
    caseDataTraining$Extended_studiso_id_Short <-
      sapply(caseDataTraining$FALL, extend_StudyIsoNumber)
    
    joined_Training <- 
      merge(x = selTraDaten,
            y = caseDataTraining,
            by.x = "Extended_studiso_id_Short",
            by.y = "Extended_studiso_id_Short")
    
    
    ################################################################################
    # Validierungsdaten
    selValDaten <- ValDaten[,c("entl_ort_ent","Extended_studiso_id_Short")]
    
    # ... Validierungssdaten
    for(i in 1:dim(selValDaten)[2]){
      tmp <- which(is.na(selValDaten[,i]))
      if(length(tmp) > 0){
        selValDaten <- selValDaten[-tmp,]
      }
    }
    
    selValDaten$entl_ort_ent <- factor(ifelse(selValDaten$entl_ort_ent == "Im Krankenhaus verstorben",1,0))
    
    caseDataValidation <- 
      caseDataValidation[,which(colnames(caseDataValidation) %in% c("FALL",nonClinicalFeaturesInModel))]
    
    
    caseDataValidation$Extended_studiso_id_Short <-
      sapply(caseDataValidation$FALL, extend_StudyIsoNumber)
    
    joined_Validation <- 
      merge(x = selValDaten,
            y = caseDataValidation,
            by.x = "Extended_studiso_id_Short",
            by.y = "Extended_studiso_id_Short")
    
    
    indices <- which(colnames(joined_Training) %in% c("entl_ort_ent",featInModel))
    
    selTraDaten <- joined_Training[,indices]
    selValDaten <- joined_Validation[,indices]
    
    library(car)
    glm_res <- glm(entl_ort_ent ~ ., data = selTraDaten, family = "binomial")
    #Anova(glm_res)
    
    glm_predicts <- 
      predict(glm_res, type = "response")
    ## Vorhersage für Trainingsdaten 
    df_TraPredictions  <-  
      data.frame(outcome = as.numeric(selTraDaten$entl_ort_ent)-1, 
                 pred = fitted(glm_res))
    
    ## Vorhersage für Validierungsdaten 
    glm_ValPredictions  <-  
      predict(glm_res, 
              type = "response", 
              newdata = selValDaten)
    df_ValPredictions  <-  data.frame(outcome = as.numeric(as.vector(selValDaten$entl_ort_ent)), 
                                      pred = glm_ValPredictions)
    
    val.error <- FALSE
    if(dim(table(df_ValPredictions$outcome)) == 1){val.error <- TRUE}
    
    library(plotROC)
    library(PRROC)
    library(OptimalCutpoints)
    
    # Beste Parameter für Training
    optimal.cutpoint.Youden.Tra <- 
      optimal.cutpoints(X = "pred", 
                        status = "outcome", 
                        tag.healthy = 0,
                        methods = "Youden", 
                        data = df_TraPredictions, 
                        pop.prev = NULL, 
                        control = control.cutpoints(), 
                        ci.fit = TRUE, conf.level = 0.95, trace = FALSE)
    optimal.cutpoint.Youden.Tra
    out[fileCounter,4:6] <- optimal.cutpoint.Youden.Tra$Youden$Global$measures.acc$AUC
    
    df_TraPredictions$outcome <- as.numeric(df_TraPredictions$outcome)
    
    if(val.error == FALSE){
      # Beste Parameter für Validierung
      optimal.cutpoint.Youden.Val <- 
        optimal.cutpoints(X = "pred", 
                          status = "outcome", 
                          tag.healthy = 0,
                          methods = "Youden", 
                          data = df_ValPredictions, 
                          pop.prev = NULL, 
                          control = control.cutpoints(), 
                          ci.fit = TRUE, conf.level = 0.95, trace = FALSE)
      optimal.cutpoint.Youden.Val
      out[fileCounter,7:9] <- optimal.cutpoint.Youden.Val$Youden$Global$measures.acc$AUC
    }else{
      out[fileCounter,5:7] <- c(NA,NA,NA)
    }
    
    
    df_predictions_training    <-  df_TraPredictions
    df_predictions_validation  <-  df_ValPredictions
    
    df_predictions_training$Type   <- "Training"
    df_predictions_validation$Type <- "Validation"
    df_predictions <- rbind(df_predictions_training,
                            df_predictions_validation)
    df_predictions <- data.frame(df_predictions)
    #head(df_predictions)
    
    # muss man nicht verstehen, aber sonst klappt es mit den Filmchen nicht!
    op <- par()
    par(op)
    
    ggplot(df_predictions, 
           aes(d = outcome, m = pred, color = Type)) + 
      geom_roc(n.cut = 0) +
      style_roc() + 
      geom_abline(slope = 1,
                  intercept = 0, 
                  color = "grey50") +
      ggtitle(paste("ROC Curves - ",length(featInModel),"Feature"))
    
    
    ggsave(paste(write_ROC_Curves_DoublePrime_to_this,"\\",substr(caseList[fileCounter],1,nchar(caseList[fileCounter])-4),".jpeg",sep = ""))
    
    if(length(featInModel) < 10){
      ggsave(paste(write_ROC_movieFiles_DoublePrime_to_this,"//00",length(featInModel),".jpeg",sep = ""))}else{
        if(length(featInModel) < 100){
          ggsave(paste(write_ROC_movieFiles_DoublePrime_to_this,"//0",length(featInModel),".jpeg",sep = ""))}else{
            ggsave(paste(write_ROC_movieFiles_DoublePrime_to_this,"//",length(featInModel),".jpeg",sep = ""))
          }
      }
    
    ggsave(paste(write_ROC_Curves_DoublePrime_pdf_to_this,"\\",substr(caseList[fileCounter],1,nchar(caseList[fileCounter])-4),".pdf",sep = ""))
    print(fileCounter)
    
    # Box-Whisker-Plots
    if(length(featInModel) < 10){
      jpeg(paste(write_BoxWhiskerPlots_DoublePrime_to_this,"\\A00",length(featInModel),".jpeg",sep = ""))}else{
        if(length(featInModel) < 100){
          jpeg(paste(write_BoxWhiskerPlots_DoublePrime_to_this,"\\A0",length(featInModel),".jpeg",sep = ""))}else{
            jpeg(paste(write_BoxWhiskerPlots_DoublePrime_to_this,"\\A",length(featInModel),".jpeg",sep = ""))
          }
      }
    
    glm_coef <- glm_res$coefficients
    
    predicted_check <-
      predict(glm_res, 
              type = "response", 
              newdata = selValDaten)
    
    # alle Trainings-Daten
    op <- par()
    
    par(mfrow = c(2,1), mar = c(2, 1, 1, 1) + 0.1)
    plot(glm_res$model[,1],glm_res$fitted.values, main = length(featInModel),
         ylab = "vorhergesagte Wahrscheinlichkeit", xlab = "Outcome")
    plot(factor(df_predictions_validation[,1]),df_predictions_validation[,2], main = length(featInModel),
         ylab = "vorhergesagte Wahrscheinlichkeit", xlab = "Outcome")
    dev.off()
    
    
    # Test-Statistiken
    KS_training_01 <- cbind(glm_res$model[,1],glm_res$fitted.values)
    KS_training_01 <- KS_training_01[order(KS_training_01[,2]),]
    out$number_inv_T[fileCounter] <- sum(diff(KS_training_01[,1]) == -1)
    wt <- wilcox.test(KS_training_01[,2] ~ KS_training_01[,1])
    out$W_stat_T[fileCounter] <- wt$statistic
    out$W_p_T[fileCounter] <- wt$p.value
    
    KS_val_01 <- cbind(factor(df_predictions_validation[,1]),
                       df_predictions_validation[,2])
    KS_val_01 <- KS_val_01[order(KS_val_01[,2]),]
    out$number_inv_V[fileCounter] <- sum(diff(KS_val_01[,1]) == -1)
    wt <- wilcox.test(KS_val_01[,2] ~ KS_val_01[,1])
    out$W_stat_V[fileCounter] <- wt$statistic
    out$W_p_V[fileCounter] <- wt$p.value
    
    ## Rang-Statistik
    KS_training_01 <- data.frame(KS_training_01)
    colnames(KS_training_01) <- c("outcome","value")
    KS_training_01$rank <- 1:dim(KS_training_01)[1]
    a_0 <- table(KS_training_01$outcome)[1]
    a_1 <- table(KS_training_01$outcome)[2]
    th_training   <- (a_0+a_1)*(a_0+a_1+1)/2 -a_0*(a_0+1)/2
    
    out$Training_Rank_Sums_0[fileCounter] <-  sum(filter(KS_training_01,outcome == 1)$rank)
    out$Training_Rank_Sums_1[fileCounter] <-  sum(filter(KS_training_01,outcome == 2)$rank)
    out$NormedTraining_Rank_Sums_1[fileCounter] <-  sum(filter(KS_training_01,outcome == 2)$rank)/th_training
    
    KS_val_01 <- data.frame(KS_val_01)
    colnames(KS_val_01) <- c("outcome","value")
    KS_val_01$rank <- 1:dim(KS_val_01)[1]
    
    a_0 <- table(KS_val_01$outcome)[1]
    a_1 <- table(KS_val_01$outcome)[2]
    th_val  <- (a_0+a_1)*(a_0+a_1+1)/2 -a_0*(a_0+1)/2
    
    out$Validation_Rank_Sums_0[fileCounter] <-  sum(filter(KS_val_01,outcome == 1)$rank)
    out$Validation_Rank_Sums_1[fileCounter] <-  sum(filter(KS_val_01,outcome == 2)$rank)
    out$NormedValidation_Rank_Sums_1[fileCounter] <-  sum(filter(KS_val_01,outcome == 2)$rank)/th_val
    par(op)
  }
}
  if(length(which(is.na(out$AUROC_T))) > 0){
    out <- out[-which(is.na(out$AUROC_T)),]
  }
  write.table(out,
              paste(in_line_analysis_folder,"\\AUROC_TABLE_DoublePrime.csv",sep=""),
              row.names = FALSE)
  
  write_xlsx(out,
             paste(report_and_analysis_folder,"\\AUROC_TABLE_DoublePrime.xlsx",sep=""))
  