#####################################################################
#   D_04_RanksumPlot:                                               #
#                                                                   #
#   This code implements:                                           #
#   1. Plots the Rank Sums and AUROC resp.                          #
#                                                                   #
#   ATTENTION: Reading the data is controlled by one central        #
#              file!                                                #
#####################################################################

library(car)
library(dplyr)
library(readxl)
library(writexl)

#=======================#
#   1. Fix file paths   #
#=======================#

source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/D_01_ANOVA_GeneSelection/01_Data/10_ControlFiles/ControlFile.R")
#source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/D_01_ANOVA_GeneSelection/01_Data/10_ControlFiles/ControlFileWithoutCD.R")

#=======================================================#
#   2. Prepare the file for the in-line-analysis        #
#=======================================================#

ILA_file <- paste(in_line_analysis_folder,"ILA_RankSumTest.txt",sep = "")
if(file.exists(ILA_file)){
  file.remove(ILA_file)  
}else{
  file.create(ILA_file)
}

#========================#
#   3. Read data         #
#========================#
in_data <- 
  read.table(paste(in_line_analysis_folder,
                   "\\AUROC_TABLE.csv",
                   sep=""), header = TRUE)
add_data <- 
  read.table(paste(write_ANOVA_to_this,
                   "/ANOVA_SELECTION_STEP_LIST.csv", 
                   sep = ""), header = FALSE,
             skip = 1, sep = ";", quote = "\"")

x <- 1

clean_add_data <- function(x){unlist(strsplit(add_data[x,],"[ ]"))}
add_data <- data.frame(t(sapply(1:dim(add_data)[1],clean_add_data)))

colnames(add_data) <- c("name","step","before","after")
add_data$step <- as.numeric(add_data$step)
add_data$before <- as.numeric(add_data$before)
add_data$after <- as.numeric(add_data$after)

mi <- min(c(in_data$NormedTraining_Rank_Sums_1,in_data$NormedValidation_Rank_Sums_1))
ma <- max(c(in_data$NormedTraining_Rank_Sums_1,in_data$NormedValidation_Rank_Sums_1))

#========================#
#   5. Plot AUROCs       #
#========================#
trainColor <- rgb(0.97, 0.46, 0.43)
valColor   <- rgb(0, 0.75, 0.77)
point.character <- "-"
point.size <- 3

par(mfrow = c(1,1), mar = c(5, 4, 4, 4) + 0.1)
ylow <- 0.3

# .. with CI
pdf(paste(write_AUROCPlots_to_this,"\\AUROC_WITH_CI_",modelName,".pdf",sep=""),
    width = 16, height = 7)
plot(in_data$number -0.08, 
     in_data$AUROC_T, 
     pch =point.character, 
     col =  trainColor,
     cex = point.size , 
     ylim = c(ylow,ma),
     ylab = "AUROC with 95% confidence intervals", xlab = "Number of significant traits and clinical factors",
     main = modelNameForPlot)
points(in_data$number +0.08, 
       in_data$AUROC_V, 
       pch =point.character, 
       col = valColor,
       cex = point.size)

for(k in 1:length(in_data$number)){
  xx <- rep(in_data$number[k],2)
  yy <- c(in_data$AUROC_T_L[k],in_data$AUROC_T_H[k])
  lines(xx-0.08,yy, col = trainColor, lwd = 4)
  
  yy <- c(in_data$AUROC_V_L[k],in_data$AUROC_V_H[k])
  lines(xx+0.08,yy, col = valColor, lwd = 4)
}

# Indices, an denen die Texte geplottet werden sollen
plot_indices_r2l <- sort(as.numeric(in_data$number),decreasing = TRUE)

for(i_plot in 1:length(add_data[,1])){
  add_this_text <- 
    add_data[i_plot,1]
  # Entferne UniRef., falls vorhanden
  if(length(grep("UniRef.", add_this_text)) > 0){
    add_this_text <- substr(add_this_text,8,nchar(add_this_text))
  }
  # sex_mb -> sex
  if(length(grep("sex_mb", add_this_text)) > 0){
    add_this_text <- "sex"
  }
  
  if(length(grep("pbs_t0", add_this_text)) > 0){
    add_this_text <- "PBS"
  }
  
  where_to_print_x <- plot_indices_r2l[i_plot]
  text(x = where_to_print_x,
       y = 0.20 + ylow, 
       labels = add_this_text,
       srt = 90, cex = 0.75
  )
}

dev.off()

