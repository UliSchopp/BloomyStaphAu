
#######################################################################
#   This code serves as the central control file                      #
#   comprising the model's name and paths to all in- and output files #
#   concerned with "only gene steps".                                 #
#######################################################################

modelName_in  <- "ModelUniref100_01"
modelName_out <- "ModelUniref100_01"

############################################################
#   Should only the increasing risk factor be considered?  #
############################################################

incrRiskOnly <- TRUE


path_I <- 
  paste(
    "S:/DataAnalysis/01_CombinedClinicalGeneticModel/B_01_PreparationOfGeneData_SpecificSteps/B.01_",
    modelName_in,
    "/01_Data/50_ProcessedData/" , sep = "")

path_II <-
"S:/DataAnalysis/01_CombinedClinicalGeneticModel/B_02_PreparationOfGeneData_CommonSteps/01_Data/"
out_data_folder <- 
  paste(path_II,modelName_out,"/50_ProcessedData/",sep="")
in_line_analysis_folder <- 
  paste(path_II,modelName_out,"/20_InLineAnalysis/",sep="")
report_and_analysis_folder <- 
  paste(path_II,modelName_out,"/70_AnalysisAndOverview/",sep="")
ToScoary_folder <- 
  paste(path_II,modelName_out,"/80_ScoryInputDataSets/",sep="")

dir.create(ToScoary_folder, showWarnings = FALSE)
dir.create(paste(path_II,modelName_out,sep=""))
dir.create(out_data_folder)
dir.create(in_line_analysis_folder)
dir.create(report_and_analysis_folder)

path_III <-
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_01_PreparationOfClinicalData/01_Data/50_ProcessedData/"

# for Cluster Analysis
path_IV <-
  "S:/DataAnalysis/01_CombinedClinicalGeneticModel/A_02_ClinicalData_FeatureSelection/01_Data/70_AnalysisAndOverview/"
path_V <-
  paste("S:/DataAnalysis/01_CombinedClinicalGeneticModel/D_01_ANOVA_GeneSelection/01_Data/",
  modelName_in,"/50_ProcessedData/AllGeneSelectionResults/",sep = "")

##############################################
#   Parameter for genes' selection in eye 1  #
##############################################
x.lw <- 0.7
x.up <- 0.85
y.lw <- 0.5
y.up <- 0.7

##########################################################
#   Threshold of p-values for genes' selection in eye 2  #
##########################################################
p.threshold <- 0.05

#################################################################
#   Threshold of p-values for genes' selection for scoary data  #
#################################################################
p.threshold.scoary <- 0.55

##########################################################
#   Other htresholds for genes' selections               #
##########################################################
relAmountBothGroups.threshold <- 0.95

