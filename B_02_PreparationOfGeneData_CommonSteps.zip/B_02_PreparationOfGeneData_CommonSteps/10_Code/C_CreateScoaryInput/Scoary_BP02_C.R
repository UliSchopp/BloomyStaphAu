#####################################################################
#   This code implements:                                           #
#   Scoary Input Data                                               #
#                                                                   #
#   ATTENTION: Reading the data is controlled by one central        #
#              file!                                                #
#####################################################################

library(dplyr)
library(writexl)

#=======================#
#   1. Fix file paths   #
#=======================#

source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/B_02_PreparationOfGeneData_CommonSteps/01_Data/10_ControlFiles/ControlFile.R")

#==============================#
#   2. Clear out-file folders  #
#==============================#

# No!

#=======================================================#
#   3. Prepare the file for the in-line-analysis        #
#=======================================================#

ILA_file <- paste(in_line_analysis_folder,"ILA_Scoary_BP02.txt",sep = "")
if(file.exists(ILA_file)){
  file.remove(ILA_file)  
}else{
  file.create(ILA_file)
}

#========================#
#   4. Read data         #
#========================#

inData <- 
  read.table(paste(out_data_folder, "mergedDataTraining.txt",sep = ""),
                     sep = ";", header = TRUE)

#==============================================#
#   5. after proportional test sieving         #
#==============================================#

selectedGeneData <-  
  read.table(paste(out_data_folder, "GenesAfterPropTestSieving.txt",sep = ""),
                     sep = "\t", header = TRUE)

indices <- which(colnames(inData) %in% c("New_Key",selectedGeneData$geneName))

tmp <- inData[,indices]

out <- 
  data.frame(GEN =colnames(tmp)[-1],
             t(tmp[,-1]),
             check.names = FALSE)
colnames(out)[-1] <- tmp[,1]

write.table(out,
            file = paste(ToScoary_folder,"genes_Training_BP02_C_AfterPropTestSieving.csv",sep = ""),
            row.names = FALSE, quote = FALSE, sep = ",")

#==============================================#
#   5. after proportional test sieving         #
#==============================================#

selectedGeneData <-  
  read.table(paste(out_data_folder, "GenesAfterPropTestSievingAndRelAmountSelection.txt",sep = ""),
             sep = "\t", header = TRUE)

indices <- which(colnames(inData) %in% c("New_Key",selectedGeneData$geneName))

tmp <- inData[,indices]

out <- 
  data.frame(GEN =colnames(tmp)[-1],
             t(tmp[,-1]),
             check.names = FALSE)
colnames(out)[-1] <- tmp[,1]

write.table(out,
            file = paste(ToScoary_folder,"genes_Training_BP02_C_AfterPropTestAndRelAmountSieving.csv",sep = ""),
            row.names = FALSE, quote = FALSE, sep = ",")
