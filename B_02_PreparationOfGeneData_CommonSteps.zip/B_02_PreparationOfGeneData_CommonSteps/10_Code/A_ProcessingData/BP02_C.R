#####################################################################
#   BP02_C:                                                         #
#                                                                   #
#   This code implements:                                           #
#   1. a first analysis of the gene data called "the eye"           #
#      which results in a figure                                    #
#   2. ...                                                          #
#                                                                   #
#   ATTENTION: Reading the data is controlled by one central        #
#              file!                                                #
#####################################################################

library(dplyr)
library(writexl)

#=======================#
#   1. Fix file paths   #
#=======================#

source("S:/DataAnalysis/01_CombinedClinicalGeneticModel/B_02_PreparationOfGeneData_CommonSteps/01_Data/10_ControlFiles/ControlFile.R")

#==============================#
#   2. Clear out-file folders  #
#==============================#
remove_old_files <- function(oldFilesFolder){
  tmp <- list.files(oldFilesFolder)
  if(length(tmp) > 0){
    file.remove(paste(oldFilesFolder,list.files(oldFilesFolder), sep = "/"))
  }  
}

remove_old_files(report_and_analysis_folder)
remove_old_files(out_data_folder)
remove_old_files(in_line_analysis_folder)

#=======================================================#
#   3. Prepare the file for the in-line-analysis        #
#=======================================================#

ILA_file <- paste(in_line_analysis_folder,"ILA_Gene_DataTransformation.txt",sep = "")
if(file.exists(ILA_file)){
  file.remove(ILA_file)  
}else{
  file.create(ILA_file)
}

#========================#
#   4. Read data         #
#========================#

inData <- read.table(paste(path_I, "castedData.csv",sep="")
                     , sep = ";", header = TRUE)

write.table(x = "\nDimension of input data frame:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(inData),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#=============================================#
#   5. Initial transformation of data         #
#=============================================#

colnames(inData)[1] <- "case"
inData$case <- rownames(inData)

make_key_B <- function(x = "RBF-17-363-A"){
  parts <- unlist(strsplit(x, "-"))
  
  out <- paste(parts[1],parts[2],parts[3],sep = "-")
}

inData$case <- sapply(inData$case, make_key_B)

make_min_1 <- function(x){
  return(pmin(x,1))
}

tmp <- apply(inData[,-1],make_min_1,MAR = 2)

inData[,-1] <- tmp 

#=============================================#
#   6. Processing the training data           #
#=============================================#

# 6.1. read the clinical meta data

ExtractTraining <- 
  read.csv(paste(path_III,"SA_Data_Step06.csv",sep=""))

ExtractTraining <- data.frame(ExtractTraining)

ExtractTraining <- filter(ExtractTraining, TrainingData == 1)

# Due to qualification of some data as training data and others
# as validation data and by the messy data structure of BLOOMY
# and PREDICT data, we need some code to merge data ...

part_BLOOMY <- filter(ExtractTraining, Source == "BLOOMY")

part_BLOOMY <-
  data.frame(FALL = part_BLOOMY$id_fall,
             ORT = part_BLOOMY$entl_ort_ent,
             STATUS = part_BLOOMY$entlstatus_ent)

make_key_A <- function(x = "RBF-17-363-A"){
  parts <- unlist(strsplit(x, "-"))
  
  if(length(parts) == 4){
    parts <- parts[-4]
  }
  parts
  if(nchar(parts[3]) == 3){
    parts[3] <- paste("0",parts[3],sep = "")
  }
  out <- paste(parts[1],parts[2],parts[3],sep = "-")
}

part_BLOOMY$New_Key <- sapply(part_BLOOMY$FALL, make_key_A)


part_BLOOMY_merged <- merge(part_BLOOMY,inData, by.x = "New_Key", by.y = "case")


## PREDICT data sets in training data
part_PREDICT <- filter(ExtractTraining, Source == "PREDICT")

part_PREDICT <-
  data.frame(FALL = part_PREDICT$Extended_studiso_id,
             ORT = part_PREDICT$entl_ort_ent,
             STATUS = part_PREDICT$entlstatus_ent)

make_key_A <- function(x = "RBF-19-0715-1"){
  substr(x,1,nchar(x)-2)
}

part_PREDICT$New_Key <- sapply(part_PREDICT$FALL, make_key_A)

part_PREDICT_merged <- merge(part_PREDICT,inData, by.x = "New_Key", by.y = "case")


merged_TrainingData <- 
  rbind(part_BLOOMY_merged, part_PREDICT_merged)

write.table(merged_TrainingData,
            paste(out_data_folder,"mergedDataTraining.txt",sep=""),
            sep = ";", row.names = FALSE, quote = TRUE)

write.table(x = "\nDimension of merged training data frame:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(merged_TrainingData),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

#=========================================================#
#   7. Preliminary analysis of the training data          #
#=========================================================#
tmp_Training <- merged_TrainingData
#unique(tmp$STATUS)
#
toAgg <- tmp_Training[,-c(1,2,3)]
#unique(toAgg$STATUS)

library(dplyr)
EL <- filter(toAgg, STATUS == "Exitus letalis")[,-1]
sum_EL <- colSums(EL)
nr_EL  <- dim(EL)[1]
NEL <- filter(toAgg, STATUS != "Exitus letalis")[,-1]
sum_NEL <- colSums(NEL)
nr_NEL  <- dim(NEL)[1]

contingencies <- rbind(sum_EL,sum_NEL)
dim(contingencies)
#contingencies[1,1:4]
#contingencies[2,1:4]

relcontigencies <- contingencies
relcontigencies[1,] <- 
  relcontigencies[1,]/nr_EL

relcontigencies[2,] <- relcontigencies[2,]/nr_NEL
#relcontigencies[1,]

relcontigencies <- data.frame(x = relcontigencies[1,],
                              y = relcontigencies[2,])

#=========================================================#
#   8. Plot the relative contingencies                    #
#=========================================================#

pdf(paste(report_and_analysis_folder,"Eye_01.pdf",sep = ""),
    width = 10, height = 10)

  plot(relcontigencies$x,relcontigencies$y, pch = 16, cex = .4,
       xlab = "Exitus Letalis", ylab = "other", main = "Genes in Training Data")


ftr <- filter(relcontigencies, x > x.lw, x < x.up, y > y.lw, y < y.up)
ftr
points(ftr$x,ftr$y, col = "blue", pch = 16, cex = 0.5)
text(x = 0.6, y = 0.2, 
     labels = paste("exitus letalis between ",x.lw *100, " and ", x.up * 100, " percent of cases",sep =""))
text(x = 0.2, y = 0.8, 
     labels = paste("other between ",y.lw *100, " and ", y.up * 100, " percent of cases",sep =""))
dev.off()


#=========================================================#
#   9. Calculate p-values for sieving                     #
#=========================================================#
# 
# for training data only!
fil_tot <- filter(merged_TrainingData, ORT == "Im Krankenhaus verstorben")
fil_leb <- filter(merged_TrainingData, ORT != "Im Krankenhaus verstorben")

write.table(x = "\nDimension of died training data frame:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(fil_tot),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = "\nDimension of survived training data frame:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = dim(fil_leb),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = "\nFrequency of outcomes in training data:",
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

write.table(x = data.frame(table(merged_TrainingData$ORT,useNA = "always")),
            file = ILA_file,
            col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)

NA_data <- which(is.na(merged_TrainingData$ORT))
if(length(NA_data) > 0){
  write.table(x = "\nTraining Data with missing status:",
              file = ILA_file,
              col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
  
  write.table(x = merged_TrainingData$New_Key[NA_data],
              file = ILA_file,
              col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
  
  merged_TrainingData$New_Key[NA_data]
}

NN <- dim(fil_leb)[2] # number of columns in both parts!
cnm <- colnames(fil_leb)
ind_gene <- grep("X.", cnm)

# data about genes are in columns 5,6,... That is NN-4 in total.
results <-
  data.frame(geneName = rep(NA, NN-4),
             x.0  = rep(NA, NN-4),
             x.1  = rep(NA, NN-4),
             y.0  = rep(NA, NN-4),
             y.1  = rep(NA, NN-4),
             pv   = rep(NA, NN-4),
             stat = rep(NA, NN-4),
             x = rep(NA, NN-4),
             y = rep(NA, NN-4))

#i <- 5
write.table(x = "\nEntry in absence/presence file lrager than 1 (now corrected - if any):", file = ILA_file, append = TRUE,
            col.names = FALSE, row.names = FALSE)

for(i in 5:NN){
  
  tmp <- which(fil_tot[,i] > 1)
  if(length(tmp > 1)){
    write.table(colnames(fil_tot)[tmp],file = ILA_file,col.names = FALSE, row.names = FALSE, append = TRUE)    
    fil_tot[tmp,i] <- 1
  }
  
  x <- fil_tot[,i]
  
  tmp <- which(fil_leb[,i] > 1)
  if(length(tmp > 1)){
    write.table(colnames(fil_leb)[tmp],file = ILA_file,col.names = FALSE, row.names = FALSE, append = TRUE)    
    fil_leb[tmp,i] <- 1
  }
  
  y <- fil_leb[,i]
  x.1 <- sum(x)
  x.0 <- length(x) - x.1
  y.1 <- sum(y)
  y.0 <- length(y) - y.1
  
  present <- c(x.1,y.1)
  cases   <- c(x.1+x.0, y.1+y.0)
  ppt     <- suppressWarnings(prop.test(present,cases))
  
  results$x.0[i-4]      = x.0 # im KH verstorben - abwesend
  results$x.1[i-4]      = x.1 # im KH verstorben - anwesend
  results$x[i-4]        = x.1/(x.0+x.1)
  results$y.0[i-4]      = y.0 # KH überlebt - abwesend
  results$y.1[i-4]      = y.1 # KH überlebt - anwesend
  results$y[i-4]        = y.1/(y.0+y.1)
  results$pv[i-4]       = ppt$p.value
  results$stat[i-4]     = ppt$statistic
  results$geneName[i-4] = cnm[i]
}

rowSums(results[1:3,2:5])

#=========================================================#
#   10.1. Select increased risk factors, if you want.     #
#=========================================================#
write.table(x = "\nOnly increased risk factors?", 
            file = ILA_file, append = TRUE,
            col.names = FALSE, row.names = FALSE, quote = FALSE)
dimBefore <- dim(results)

if(incrRiskOnly == TRUE){
  results <- results[which(results$x > results$y),]
  write.table(x = "\nYes!", 
              file = ILA_file, append = TRUE,
              col.names = FALSE, row.names = FALSE, quote = FALSE)}else{
                write.table(x = "\nNo!", 
                            file = ILA_file, append = TRUE,
                            col.names = FALSE, row.names = FALSE, quote = FALSE)
                
              }

dimAfter <- dim(results)

if(incrRiskOnly == TRUE){
  write.table(x = 
                paste("\nAfter selection of increased risk factors,",
                      dimAfter[1], "of", dimBefore[1],"elements were selected."), 
              file = ILA_file, append = TRUE,
              col.names = FALSE, row.names = FALSE, quote = FALSE)
}

#=========================================================#
#   10.2 sieve and plot                                   #
#=========================================================#
# 
# for training data only!

pdf(paste(report_and_analysis_folder,"Eye_02.pdf",sep = ""),
    width = 10, height = 10)

  sel_res <- results[which(results$pv > p.threshold),]
  plot(sel_res$x,sel_res$y, pch = 16, cex = 0.5, col = "grey40",
       xlab = "Exitus Letalis", ylab = "other",
       main = "p-values less or equal then 5% (Training data only!)")

  results <- results[order(results$pv, decreasing = FALSE),]

  # x > y
  sel_res_xlary <- results[which(results$pv <= p.threshold &
                                 results$x > results$y),]

  points(sel_res_xlary$x, sel_res_xlary$y, cex = 0.6, col = "red", pch = 16)
  sel_res_xlary$xy <- "larger in outcome death than surviving"
  
  if(incrRiskOnly == FALSE){
    sel_res_ylarx <- results[which(results$pv <= p.threshold &
                                     results$x <= results$y),]
    
    points(sel_res_ylarx$x, sel_res_ylarx$y, cex = 0.6, col = "green", pch = 16)
    
    sel_res_ylarx$xy <- "larger in outcome suviving then death"
  }

# other interesting points
  sel_res_other <- results[which(results$geneName == "mecA"),]
  points(sel_res_other$x, sel_res_other$y, cex = 0.6, col = "magenta", pch = 16)
dev.off()

if(incrRiskOnly == FALSE){
sel_res <- 
  rbind(sel_res_xlary, sel_res_ylarx)}else{
    sel_res <- sel_res_xlary
  }

oldnames.sel_res  <- colnames(sel_res)

write.table(sel_res,
            paste(out_data_folder,"GenesAfterPropTestSieving.txt",sep = ""),
            sep = "\t", quote = TRUE)

colnames(sel_res)[2] <- "died and gene absent"
colnames(sel_res)[3] <- "died and gene present"
colnames(sel_res)[4] <- "survived and gene absent"
colnames(sel_res)[5] <- "survived and gene present"
colnames(sel_res)[8] <- "fraction of 'gene present' for all died"
colnames(sel_res)[9] <- "fraction of 'gene present' for all survived"
colnames(sel_res)[10] <- "which is more?"

write_xlsx(sel_res,
           paste(report_and_analysis_folder,"GenesAfterPropTestSieving.xlsx",sep = ""))


part_data <- sel_res[,c(1,6,8,9,2,3,4,5)]
row.names(part_data) <- NULL

part_data[,2] <- round(part_data[,2]*100,2)
part_data[,3] <- round(part_data[,3]*100,0)
part_data[,4] <- round(part_data[,4]*100,0)

colnames(part_data) <- c("Gene name", "p-value", "rel. death", "rel. suvived", 
                         "d & a", "d & p",
                         "s & a", "s & p")
write_xlsx(part_data,
            paste(report_and_analysis_folder,"Tabelle_5_2.xlsx",sep = ""))

#=========================================================#
#   11. Further restriction on relative frequency:        #
#       Selection and plot.                               #
#=========================================================#
# 
# for training data only!
colnames(sel_res) <- oldnames.sel_res
sel_res$relAmountBothGroups <- 
  (sel_res$x.1 + sel_res$y.1)/(sel_res$x.0 + sel_res$y.0 + sel_res$x.1 + sel_res$y.1)

sel2_res <- 
  filter(sel_res, relAmountBothGroups > p.threshold  & 
           relAmountBothGroups <= relAmountBothGroups.threshold)

part_data <- sel2_res[,c(1,6,8,9,
                         2,3,4,5)]
row.names(part_data) <- NULL


part_data[,2] <- round(part_data[,2]*100,2)
part_data[,3] <- round(part_data[,3]*100,0)
part_data[,4] <- round(part_data[,4]*100,0)

write.table(sel2_res,
            paste(out_data_folder,"GenesAfterPropTestSievingAndRelAmountSelection.txt",sep = ""),
            sep = "\t", quote = TRUE)

colnames(part_data) <- c("Gene name", "p-value", "rel. death", "rel. suvived", 
                         "d & a", "d & p",
                         "s & a", "s & p")
write_xlsx(part_data,
            paste(report_and_analysis_folder,"Tabelle_5_3.txt",sep = ""))

#=============================================#
#   12. Processing the validation data        #
#=============================================#
ExtraktValidation <- 
  read.csv(paste(path_III,"SA_Data_Step06.csv",sep=""))

ExtraktValidation <- data.frame(ExtraktValidation)

ExtraktValidation <- filter(ExtraktValidation, TrainingData == 0)

# Due to qualification of some data as training data and others
# as validation data and by the messy data structure of BLOOMY
# and PREDICT data, we need some code to merge data ...

part_BLOOMY <- filter(ExtraktValidation, Source == "BLOOMY")

part_BLOOMY <-
  data.frame(FALL = part_BLOOMY$id_fall,
             ORT = part_BLOOMY$entl_ort_ent,
             STATUS = part_BLOOMY$entlstatus_ent)

make_key_A <- function(x = "RBF-17-363-A"){
  parts <- unlist(strsplit(x, "-"))
  
  if(length(parts) == 4){
    parts <- parts[-4]
  }
  parts
  if(nchar(parts[3]) == 3){
    parts[3] <- paste("0",parts[3],sep = "")
  }
  out <- paste(parts[1],parts[2],parts[3],sep = "-")
}

part_BLOOMY$New_Key <- sapply(part_BLOOMY$FALL, make_key_A)

part_BLOOMY_merged <- merge(part_BLOOMY,inData, by.x = "New_Key", by.y = "case")

## PRDICT data sets in Validation data
part_PREDICT <- filter(ExtraktValidation, Source == "PREDICT")

part_PREDICT <-
  data.frame(FALL = part_PREDICT$Extended_studiso_id,
             ORT = part_PREDICT$entl_ort_ent,
             STATUS = part_PREDICT$entlstatus_ent)

make_key_A <- function(x = "RBF-19-0715-1"){
  substr(x,1,nchar(x)-2)
}

part_PREDICT$New_Key <- sapply(part_PREDICT$FALL, make_key_A)

part_PREDICT_merged <- merge(part_PREDICT,inData, by.x = "New_Key", by.y = "case")


merged_ValidationData <- 
  rbind(part_BLOOMY_merged, part_PREDICT_merged)

write.table(merged_ValidationData,
            paste(out_data_folder,"mergedDataValidation.txt",sep=""),
            sep = ";", row.names = FALSE, quote = TRUE)

NA_data <- which(is.na(merged_ValidationData$ORT))
if(length(NA_data) > 0){
  write.table(x = "\nValidation Data with missing status:",
              file = ILA_file,
              col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
  
  write.table(x = merged_ValidationData$New_Key[NA_data],
              file = ILA_file,
              col.names = FALSE, row.names = FALSE, append = TRUE, quote = FALSE)
  
  merged_TrainingData$New_Key[NA_data]
}

